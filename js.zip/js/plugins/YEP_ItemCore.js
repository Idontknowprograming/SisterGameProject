//=============================================================================
// Yanfly Engine Plugins - Item Core
// YEP_ItemCore.js
//=============================================================================

var Imported = Imported || {};
Imported.YEP_ItemCore = true;

var Yanfly = Yanfly || {};
Yanfly.Item = Yanfly.Item || {};
Yanfly.Item.version = 1.30;

//=============================================================================
 /*:
 * @plugindesc v1.30 Changes the way Items are handled for your game
 * and the Item Scene, too.
 * @author Yanfly Engine Plugins
 *
 * @param ---General---
 * @default
 *
 * @param Max Items
 * @parent ---General---
 * @type number
 * @min 0
 * @desc Maximum number of items. If this is set to 0, then there
 * will be no independent items.
 * @default 0
 *
 * @param Max Weapons
 * @parent ---General---
 * @type number
 * @min 0
 * @desc Maximum number of weapons. If this is set to 0, then there
 * will be no independent weapons.
 * @default 100
 *
 * @param Max Armors
 * @parent ---General---
 * @type number
 * @min 0
 * @desc Maximum number of armors. If this is set to 0, then there
 * will be no independent armors.
 * @default 100
 *
 * @param Starting ID
 * @parent ---General---
 * @type number
 * @min 1
 * @desc This will be the starting ID number for independent items
 * so that they don't interfere with default items.
 * @default 3000
 *
 * @param Random Variance
 * @parent ---General---
 * @type number
 * @desc Randomize the stats found for non shop items by this value
 * either positive or negative. Set as 0 for no random.
 * @default 0
 *
 * @param Negative Variance
 * @parent ---General---
 * @type boolean
 * @on Allow
 * @off Disallow
 * @desc If using random variance, allow random variance equipment
 * stats to go under 0? NO - false     YES - true
 * @default false
 *
 * @param Name Format
 * @parent ---General---
 * @desc How item names will be ordered and structured.
 * %1 - Prefix, %2 - Base Name, %3 - Suffix, %4 Boost
 * @default %1%2%3%4
 *
 * @param Name Spacing
 * @parent ---General---
 * @type boolean
 * @on YES
 * @off NO
 * @desc Place a space between name prefixes and suffixes?
 * NO - false     YES - true
 * @default true
 *
 * @param Boost Format
 * @parent ---General---
 * @desc This is the text format for a boosted independent item.
 * %1 - Boost Amount
 * @default (+%1)
 *
 * @param ---Item Scene---
 * @default
 *
 * @param Updated Scene Item
 * @parent ---Item Scene---
 * @type boolean
 * @on Updated (Recommended)
 * @off Normal
 * @desc Enabling this will change Scene Item's visual appearance.
 * NO - false     YES - true (recommended)
 * @default true
 *
 * @param List Equipped Items
 * @parent ---Item Scene---
 * @type boolean
 * @on YES
 * @off NO
 * @desc Show equipped independent items in the item lists?
 * NO - false     YES - true
 * @default true
 *
 * @param Show Icon
 * @parent ---Item Scene---
 * @type boolean
 * @on YES
 * @off NO
 * @desc Show the icon in the status window?
 * NO - false     YES - true
 * @default true
 *
 * @param Icon Size
 * @parent ---Item Scene---
 * @type number
 * @min 0
 * @desc This will be the width and height of the icon to be drawn.
 * This is normally 4x the default Icon Width and Icon Height.
 * @default 128
 *
 * @param Font Size
 * @parent ---Item Scene---
 * @type number
 * @min 1
 * @desc This changes the font size for description items.
 * Default: 28
 * @default 20
 *
 * @param Command Alignment
 * @parent ---Item Scene---
 * @type combo
 * @option left
 * @option center
 * @option right
 * @desc This is the text alignment for the command windows.
 * left     center     right
 * @default center
 *
 * @param Recovery Format
 * @parent ---Item Scene---
 * @desc This is the text format for HP/MP Recovery.
 * @default %1 Heal
 *
 * @param Add State
 * @parent ---Item Scene---
 * @desc This is the text for adding states.
 * @default +State
 *
 * @param Add Buff
 * @parent ---Item Scene---
 * @desc This is the text for adding buffs.
 * @default +Buff
 *
 * @param Remove State
 * @parent ---Item Scene---
 * @desc This is the text for remove states.
 * @default -State
 *
 * @param Remove Buff
 * @parent ---Item Scene---
 * @desc This is the text for remove buffs.
 * @default -Buff
 *
 * @param Maximum Icons
 * @parent ---Item Scene---
 * @type number
 * @min 0
 * @desc Maximum number of icons drawn for states and buffs.
 * @default 4
 *
 * @param Use Command
 * @parent ---Item Scene---
 * @desc Command text for using the selected item.
 * %1 - Item Icon and Name
 * @default Use %1
 *
 * @param Carry Format
 * @parent ---Item Scene---
 * @desc This is the visual text format for independent item ID.
 * %1 - Item Index     %2 - Maximum
 * @default %1/%2
 *
 * @param --Independent Items--
 * @default
 *
 * @param Midgame Note Parsing
 * @parent ---Independent Items---
 * @type boolean
 * @on YES
 * @off NO (Recommended)
 * @desc Allow midgame note parsing or do it at beginning?
 * NO - false     YES - true    Recommended: false
 * @default false
 *
 * @help
 * ============================================================================
 * Introduction
 * ============================================================================
 *
 * This plugin makes a couple of main changes to your game and the way items
 * are handled to allow a base core for future plugins.
 *
 * 1. Independent Items
 * If you choose to have maximum limit on your items, weapons, and/or armors,
 * those items will become independent and have their own individual stats and
 * whatnot. Independent items are capable of being upgraded, altered, modified,
 * etc. and retain those changed properties independent of other items of the
 * same type. Items without a maximum limit (aka 0), will continue working as
 * they normally did in RPG Maker MV.
 *
 * 2. New Scene_Item
 * The item scene has been revamped to look a little bit different. With the
 * new layout, the item list is no longer two columns, but one. Added are a few
 * more windows, such as the item status window (which displays basic item
 * information), an item information window (which shows information applied to
 * the item via upgrades, etc.), and an item action window, which appears when
 * you select an item and it will ask you if you wish to Use the item or any
 * action added via plugins (such as upgrading the item). If you wish to not
 * use this revamp, you can disable it from the parameters.
 *
 * 3. Random Variance
 * Newly acquired items that aren't from shop can be given randomized stats to
 * a small degree for items that are independent. Items can be above the stock
 * value or below the stock value by the variance value. If you wish for an
 * item to not have a variance value, you can use a notetag to set the variance
 * value to 0. If you wish for all of your items to not have a variance value,
 * you can set the parameter to 0.
 *
 * Note: During battle test, independent items are disabled.
 *
 * ============================================================================
 * Notetags
 * ============================================================================
 *
 * If you are using independent items, items that aren't gained through the
 * shop can have a random variance applied to its stats.
 *
 * Item, Weapon, Armor Notetag
 *   <Random Variance: x>
 *   If this item is acquired through non-shop means, it will have random
 *   stats offset by x amount in either a positive or negative value.
 *
 *   <Not Independent Item>
 *   Sets an item that is independent by default to become a nonindependent
 *   item, allowing it to stack and making it unable to be affected by
 *   independent item modifiers.
 *
 *   <Priority Name>
 *   This sets the item, weapon, or armor's priority name to its database
 *   entry so that name schemes cannot affect the item.
 *
 *   <Text Color: x>
 *   This sets the text color of this item, weapon, or armor to use text color
 *   x from the window skin.
 *
 * ============================================================================
 * Plugin Commands
 * ============================================================================
 *
 * If you wish to be able to add items to your player's inventory without the
 * random variance being applied to it, you can use the following plugin
 * commands to adjust the settings for that.
 *
 * Plugin Command:
 *   EnableVarianceStock  - Causes all items acquired from this point forward
 *                          to have its variance give stock (nonrandom) values.
 *   DisableVarianceStock - Causes all items acquired from this point forward
 *                          to have its variance give random values.
 *
 * A small note is that if you enabled the variance stock values, if the player
 * restarts the game by either going through the title screen or just turning
 * off the program and starting it back up, the random variance will be in
 * effect again. This plugin command is meant to exist as a short term disable.
 *
 * ============================================================================
 * Eventing Changes
 * ============================================================================
 *
 * A few changes have been made to eventing in order to adjust for independent
 * items. They are as follows:
 *
 * Event Page Conditions and Conditional Branches:
 *   Checking to see if an item exists in the party's inventory will differ if
 * the item can be independent. Instead, the condition can be fulfilled if
 * there is an item, even when upgraded, that has the selected item as the base
 * item. This means your Long Sword (+1) will fulfill the condition of having
 * the target Long Sword item in the event editor.
 *
 * Actor Has X Equip:
 *   Just like the previous condition, this condition will be fulfilled if the
 * actor has a weapon whose base item matches the event editor's target item.
 * The Long Sword (+1) will fulfill the condition of needing the actor to have
 * a Long Sword item equipped.
 *
 * Change Equipment:
 *   If the target equipment is independent, the game will first check to see
 * if the actor has an item equipped with the matching base item. If not, the
 * game will then check to see if the party has a matching base item in the
 * inventory first and use that. If not, then the game will create a new stock
 * version of the item and equip that to the actor.
 *
 * ============================================================================
 * Item Name System
 * ============================================================================
 *
 * For independent items, they have a unique name handling system. Independent
 * items consist of four parts:
 *
 *      Prefix     Base Name     Suffix     Boost Count
 *
 * The prefix, base name, suffix, and boost count are adjusted by plugins.
 * Depending on the effects applied, they can be altered or changed. Using the
 * name system, an item with a prefix of 'Fiery', base name of 'Sword', suffix
 * being 'of Might', and a boost count of 5 will end up looking like:
 *
 *      Fiery Sword of Might (+5)
 *
 * This item would appear that way only if its various name parts have been
 * altered some way or another. However, there is a fifth name convention, and
 * that is the priority name. If an item has a priority name, it will completely
 * overwrite the current name scheme with just the priority name itself. So even
 * if the item's name is 'Fiery Sword of Might (+5)', if the item's priority
 * name is 'Legendary Blade', then 'Legendary Blade' will take priority.
 *
 * ============================================================================
 * Lunatic Mode - On Independent Item Creation
 * ============================================================================
 *
 * For those with JavaScript experience, you can use the following Lunatic Mode
 * to run JavaScript code upon the creation of the item. This only applies to
 * newly made independent items.
 *
 * Item, Weapon, Armor
 *
 *   <On Creation Eval>
 *    item.price = baseItem.price;
 *    item.price += Math.floor(Random() * 100);
 *   </On Creation Eval>
 *   The 'item' variable refers to the independent item being made. 'baseItem'
 *   refers to the item's base item. Any alterations made to the 'item' will be
 *   applied to the independent item.
 *
 * ============================================================================
 * Lunatic Mode - Custom Info Window Display
 * ============================================================================
 *
 * If you want to display unique and custom stuff into your info window on the
 * side, you can use the following notetags:
 *
 *   <Info Text Top>
 *    text
 *    text
 *   </Info Text Top>
 *   Type in extra information you wish to type in for the item info window
 *   here, whether it is lore or other information. Text codes can be used.
 *   Information here is is displayed towards the top of the info window.
 *
 *   <Info Text Bottom>
 *    text
 *    text
 *   </Info Text Bottom>
 *   Type in extra information you wish to type in for the item info window
 *   here, whether it is lore or other information. Text codes can be used.
 *   Information here is is displayed towards the bottom of the info window.
 *
 *   <Info Eval>
 *    var variableId = 1;
 *    var value = 500;
 *    $gameVariables.setValue(variableId, value);
 *   </Info Eval>
 *   If you know JavaScript, you can use these notetags to run some code before
 *   displaying any new info. This way, if you plan on using text codes that
 *   display variable values, you can run a bit of code before displaying them
 *   to synch up what's shown in the item info window.
 *
 * ============================================================================
 * Independent Items and Midgame Note Parsing
 * ============================================================================
 *
 * The "Midgame Note Parsing" option in the plugin parameters is made for any
 * plugins that may only parse notetags midgame as opposed to at the loading of
 * the game. This is an option that you should enable AT YOUR OWN RISK.
 *
 * Why is it at your own risk? Because enabling this option means independent
 * items will keep their notedata, thus, increasing the file sizes of your save
 * files several times bigger, and it can cause lag midgame, too.
 *
 * ============================================================================
 * Changelog
 * ============================================================================
 *
 * Version 1.30:
 * - Bypass the isDevToolsOpen() error when bad code is inserted into a script
 * call or custom Lunatic Mode code segment due to updating to MV 1.6.1.
 *
 * Version 1.29:
 * - Updated for RPG Maker MV version 1.6.0:
 *   Removal of the destructive code in Scene_Item.update function.
 *
 * Version 1.28:
 * - Updated for RPG Maker MV version 1.5.0.
 *
 * Version 1.27:
 * - Compatibility update for future plugins.
 *
 * Version 1.26:
 * - Lunatic Mode fail safes added.
 *
 * Version 1.25:
 * - Optimization Update
 *
 * Version 1.24a:
 * - Fixed a typo within the code. Please update Item Core, Item Disassemble,
 * Attachable Augments, and More Currencies if you are using those plugins.
 * - Random variance is now disabled from fresh plugin installation by default.
 *
 * Version 1.23:
 * - Fixed an issue custom info text when using different font sizes.
 *
 * Version 1.22:
 * - Fixed a removal bug that caused weapon and armor ID's to clash.
 *
 * Version 1.21:
 * - Fixed an error with sorting algorithm when items have the same base ID.
 *
 * Version 1.20:
 * - Added <On Creation Eval> Lunatic Mode notetag. Read the help file for more
 * information about it.
 *
 * Version 1.19:
 * - Updated for RPG Maker MV version 1.1.0.
 *
 * Version 1.18a:
 * - Added 'Midgame Note Parsing' plugin parameter.
 * - Fixed a visual error with MP recovery displaying a 0 instead of ---.
 *
 * Version 1.17:
 * - Added <Text Color: x> notetag for items, weapons, and armors.
 *
 * Version 1.16:
 * - Fixed a bug that made mid-game actor initialization not display items
 * correctly in the item menu.
 *
 * Version 1.15:
 * - Fixed a bug with independent items getting values that crash the game.
 *
 * Version 1.14:
 * - Fixed an unintended function of the game not granting a piece of equipment
 * through events.
 *
 * Version 1.13:
 * - Fixed a bug that didn't unequip items properly.
 *
 * Version 1.12:
 * - Added 'Negative Variance' parameter.
 *
 * Version 1.11:
 * - Fixed a bug that caused random variance to not calculate correctly.
 * - Fixed a bug that didn't return the correct conditional branch results.
 * - Fixed the display in the shop window to show number of independent items
 * owned by the player rather than just 0.
 *
 * Version 1.10:
 * - Added Lunatic Mode - Custom Info Window Display.
 *
 * Version 1.09:
 * - Fixed a bug with evented item removal that didn't remove equipped items if
 * the 'Include Equipment' checkbox was checked.
 *
 * Version 1.08:
 * - Fixed a bug with the Control Variable event that would not gather the
 * right amount of independent items.
 *
 * Version 1.07:
 * - Fixed a bug with the Change Equipment event where armors wouldn't equip.
 *
 * Version 1.06:
 * - Fixed a bug and rewrote the initializing equipment process.
 *
 * Version 1.05:
 * - Compatibility update with ItemBook.
 *
 * Version 1.04:
 * - Added 'List Equipped Items' parameter to allow for equipment restricted
 * actors to be able to alt their equipment.
 *
 * Version 1.03:
 * - Fixed a bug where using events to remove independent items weren't working
 * properly and instead added more items.
 * - Fixed a bug where a Random Variance of 0 still gave random stats.
 *
 * Version 1.02:
 * - Fixed a bug where initializing equipment slots didn't work properly and/or
 * added incorrect equips from the wrong actors into the inventory.
 *
 * Version 1.01:
 * - Fixed bug where if you are using no independent pieces of equipment,
 * actors would fail to start with initial equipment.
 *
 * Version 1.00:
 * - Finished plugin!
 */
//=============================================================================

//=============================================================================
// Parameter Variables
//=============================================================================

Yanfly.Parameters = PluginManager.parameters('YEP_ItemCore');
Yanfly.Param = Yanfly.Param || {};

Yanfly.Param.ItemMaxItems = Number(Yanfly.Parameters['Max Items']);
Yanfly.Param.ItemMaxWeapons = Number(Yanfly.Parameters['Max Weapons']);
Yanfly.Param.ItemMaxArmors = Number(Yanfly.Parameters['Max Armors']);
Yanfly.Param.ItemStartingId = Number(Yanfly.Parameters['Starting ID']);
Yanfly.Param.ItemRandomVariance = Number(Yanfly.Parameters['Random Variance']);
Yanfly.Param.ItemNegVar = eval(String(Yanfly.Parameters['Negative Variance']));
Yanfly.Param.ItemNameFmt = String(Yanfly.Parameters['Name Format']);
Yanfly.Param.ItemNameSpacing = String(Yanfly.Parameters['Name Spacing']);
Yanfly.Param.ItemBoostFmt = String(Yanfly.Parameters['Boost Format']);

Yanfly.Param.ItemSceneItem = String(Yanfly.Parameters['Updated Scene Item']);
Yanfly.Param.ItemSceneItem = eval(Yanfly.Param.ItemSceneItem);
Yanfly.Param.ItemShEquipped = String(Yanfly.Parameters['List Equipped Items']);
Yanfly.Param.ItemShEquipped = eval(Yanfly.Param.ItemShEquipped);
Yanfly.Param.ItemShowIcon = String(Yanfly.Parameters['Show Icon']);
Yanfly.Param.ItemShowIcon = eval(Yanfly.Param.ItemShowIcon);
Yanfly.Param.ItemIconSize = Number(Yanfly.Parameters['Icon Size']);
Yanfly.Param.ItemFontSize = Number(Yanfly.Parameters['Font Size']);
Yanfly.Param.ItemCmdAlign = String(Yanfly.Parameters['Command Alignment']);
Yanfly.Param.ItemRecoverFmt = String(Yanfly.Parameters['Recovery Format']);
Yanfly.Param.ItemAddState = String(Yanfly.Parameters['Add State']);
Yanfly.Param.ItemAddBuff = String(Yanfly.Parameters['Add Buff']);
Yanfly.Param.ItemRemoveState = String(Yanfly.Parameters['Remove State']);
Yanfly.Param.ItemRemoveBuff = String(Yanfly.Parameters['Remove Buff']);
Yanfly.Param.ItemMaxIcons = Number(Yanfly.Parameters['Maximum Icons']);
Yanfly.Param.ItemUseCmd = String(Yanfly.Parameters['Use Command']);
Yanfly.Param.ItemCarryFmt = String(Yanfly.Parameters['Carry Format']);

Yanfly.Param.ItemNoteParse = String(Yanfly.Parameters['Midgame Note Parsing']);
Yanfly.Param.ItemNoteParse = eval(Yanfly.Param.ItemNoteParse);

//=============================================================================
// DataManager
//=============================================================================

Yanfly.Item.DataManager_isDatabaseLoaded = DataManager.isDatabaseLoaded;
DataManager.isDatabaseLoaded = function() {
  if (!Yanfly.Item.DataManager_isDatabaseLoaded.call(this)) return false;
  if (!Yanfly._loaded_YEP_ItemCore) {
    this.setDatabaseLengths();
    this.processItemCoreNotetags($dataItems);
    this.processItemCoreNotetags($dataWeapons);
    this.processItemCoreNotetags($dataArmors);
    Yanfly._loaded_YEP_ItemCore = true;
  }
  return true;
};

DataManager.processItemCoreNotetags = function(group) {
  var note1 = /<(?:RANDOM VARIANCE):[ ](\d+)>/i;
  var note2 = /<(?:BE INDEPENDENT ITEM|be independent item)>/i;
  var note3 = /<(?:PRIORITY NAME)>/i;
  for (var n = 1; n < group.length; n++) {
    var obj = group[n];
    var notedata = obj.note.split(/[\r\n]+/);

    obj.randomVariance = Yanfly.Param.ItemRandomVariance;
    obj.textColor = 0;
    if (Imported.YEP_CoreEngine) obj.textColor = Yanfly.Param.ColorNormal;
    obj.beIndependent = false;
    obj.setPriorityName = false;
    obj.infoEval = '';
    obj.infoTextTop = '';
    obj.infoTextBottom = '';
    obj.onCreationEval = '';
    obj.onGainEval = '';
    var evalMode = 'none';

   for (var i = 0; i < notedata.length; i++) {
     var line = notedata[i];
     if (line.match(note1)) {
       obj.randomVariance = parseInt(RegExp.$1);
      } else if (line.match(note2)) {
        obj.beIndependent = true;
      } else if (line.match(note3)) {
        obj.setPriorityName = true;
      } else if (line.match(/<(?:INFO EVAL)>/i)) {
        evalMode = 'info eval';
      } else if (line.match(/<\/(?:INFO EVAL)>/i)) {
        evalMode = 'none';
      } else if (line.match(/<(?:INFO TEXT TOP)>/i)) {
        evalMode = 'info text top';
      } else if (line.match(/<\/(?:INFO TEXT TOP)>/i)) {
        evalMode = 'none';
      } else if (line.match(/<(?:INFO TEXT BOTTOM)>/i)) {
        evalMode = 'info text bottom';
      } else if (line.match(/<\/(?:INFO TEXT BOTTOM)>/i)) {
        evalMode = 'none';
      } else if (evalMode === 'info eval') {
        obj.infoEval = obj.infoEval + line + '\n';
      } else if (evalMode === 'info text top') {
        if (obj.infoTextTop !== '') obj.infoTextTop += '\n';
        obj.infoTextTop = obj.infoTextTop + line;
      } else if (evalMode === 'info text bottom') {
        if (obj.infoTextBottom !== '') obj.infoTextBottom += '\n';
        obj.infoTextBottom = obj.infoTextBottom + line;
      } else if (line.match(/<(?:TEXT COLOR):[ ](\d+)>/i)) {
        obj.textColor = parseInt(RegExp.$1);
      } else if (line.match(/<(?:ON CREATE EVAL|ON CREATION EVAL)>/i)) {
        evalMode = 'on create eval';
      } else if (line.match(/<\/(?:ON CREATE EVAL|ON CREATION EVAL)>/i)) {
        evalMode = 'none';
      } else if (evalMode === 'on create eval') {
        obj.onCreationEval = obj.onCreationEval + line + '\n';
      } else if (line.match(/<On Gain Eval>/i)) {
        evalMode = 'on gain eval';
      } else if (line.match(/<\/On Gain Eval>/i)) {
        evalMode = 'none';
      } else if (evalMode === 'on gain eval') {
        obj.onGainEval = obj.onGainEval + line + '\n';
      }
    }
  }
};

DataManager.setDatabaseLengths = function() {
    this._baseItemsLength   = $dataItems.length
    this._baseWeaponsLength = $dataWeapons.length
    this._baseArmorsLength  = $dataArmors.length
};

Yanfly.Item.DataManager_createGameObjects =
    DataManager.createGameObjects;
DataManager.createGameObjects = function() {
    Yanfly.Item.DataManager_createGameObjects.call(this);
    this.createIndependentObjects();
};

DataManager.createIndependentObjects = function() {
    DataManager.createIndependentGroups();
    this.loadIndependentItems();
};

DataManager.loadIndependentItems = function() {
    if (Yanfly.Param.ItemMaxItems > 0) {
      var difItems = $dataItems.length - DataManager._baseItemsLength;
      $dataItems.splice(DataManager._baseItemsLength, difItems);
      this.setIndependentLength($dataItems);
      $dataItems = $dataItems.concat(this._independentItems);
    }
    if (Yanfly.Param.ItemMaxWeapons > 0) {
      var difWeapons = $dataWeapons.length - DataManager._baseWeaponsLength;
      $dataWeapons.splice(DataManager._baseWeaponsLength, difWeapons);
      this.setIndependentLength($dataWeapons);
      $dataWeapons = $dataWeapons.concat(this._independentWeapons);
    }
    if (Yanfly.Param.ItemMaxArmors > 0) {
      var difArmors = $dataArmors.length - DataManager._baseArmorsLength;
      $dataArmors.splice(DataManager._baseArmorsLength, difArmors);
      this.setIndependentLength($dataArmors);
      $dataArmors = $dataArmors.concat(this._independentArmors);
    }
};

DataManager.setIndependentLength = function(group) {
    for (;;) {
      if (group.length > Yanfly.Param.ItemStartingId) break;
      group.push(null);
    }
};

DataManager.saveGameWithoutRescue = function(savefileId) {
    var json = JsonEx.stringify(this.makeSaveContents());
    StorageManager.save(savefileId, json);
    this._lastAccessedId = savefileId;
    var globalInfo = this.loadGlobalInfo() || [];
    globalInfo[savefileId] = this.makeSavefileInfo();
    this.saveGlobalInfo(globalInfo);
    return true;
};

Yanfly.Item.DataManager_makeSaveContents = DataManager.makeSaveContents;
DataManager.makeSaveContents = function() {
    var contents = Yanfly.Item.DataManager_makeSaveContents.call(this);
    contents.items = this._independentItems;
    contents.weapons = this._independentWeapons;
    contents.armors = this._independentArmors;
    return contents;
};

Yanfly.Item.DataManager_extractSaveContents =
    DataManager.extractSaveContents;
DataManager.extractSaveContents = function(contents) {
    Yanfly.Item.DataManager_extractSaveContents.call(this, contents);
    this._independentItems = contents.items || [];
    this._independentWeapons = contents.weapons || [];
    this._independentArmors = contents.armors || [];
    this.loadIndependentItems();
};

DataManager.createIndependentGroups = function() {
    this._independentItems = [];
    this._independentWeapons = [];
    this._independentArmors = [];
};

DataManager.isIndependent = function(item) {
    if (!item) return false;
    if (DataManager.isBattleTest()) return false;
    if (item.beIndependent) return true;
    if (DataManager.isItem(item)) return Yanfly.Param.ItemMaxItems > 0;
    if (DataManager.isWeapon(item)) return Yanfly.Param.ItemMaxWeapons > 0;
    if (DataManager.isArmor(item)) return Yanfly.Param.ItemMaxArmors > 0;
    return false;
};

DataManager.registerNewItem = function(item) {
    if (!this.isNewItemValid(item)) return item;
    var newItem = JsonEx.makeDeepCopy(item);
    this.addNewIndependentItem(item, newItem);
    return newItem;
};

DataManager.isNewItemValid = function(item) {
    if (!item) return false;
    if (item.baseItemId) return false;
    return item.id === this.getDatabase(item).indexOf(item);
};

//新增记录独立物品ID的变量
DataManager.addNewIndependentItem = function(baseItem, newItem) {
    newItem.id = this.getDatabase(baseItem).length;
	$gameVariables.setValue(305, newItem.id);
    ItemManager.setNewIndependentItem(baseItem, newItem);
    ItemManager.customizeNewIndependentItem(baseItem, newItem);
    ItemManager.onCreationEval(baseItem, newItem);
    this.getDatabase(baseItem).push(newItem);
    this.getContainer(baseItem).push(newItem);

    // 只在真正创建独立装备时累计；已有实例的重捡、穿脱和归还不会进入这里。
    // 按基础 ID 保存到当前存档，不随独立实例删除、重新编号而丢失。
    const kind = this.isWeapon(baseItem) ? 'weapon' :
        this.isArmor(baseItem) ? 'armor' : null;
    if (kind) {
        $gameSystem.recordFirstCollectedItemTime?.(kind, baseItem.id);
        const counts = $gameSystem._independentEquipCollectionCounts ||
            ($gameSystem._independentEquipCollectionCounts = {});
        const byId = counts[kind] || (counts[kind] = {});
        byId[baseItem.id] = (byId[baseItem.id] || 0) + 1;
    }
};

// type: 'weapon' / 'armor'，baseItemId: 数据库中的基础装备 ID。
// 旧存档没有历史累计数据，未记录的条目返回 0；读取本身不修改存档。
Game_System.prototype.independentEquipCollectionCount = function(type, baseItemId) {
    if (type !== 'weapon' && type !== 'armor') return 0;
    if (!Number.isInteger(baseItemId) || baseItemId <= 0) return 0;
    const counts = this._independentEquipCollectionCounts;
    return counts && counts[type] ? counts[type][baseItemId] || 0 : 0;
};

DataManager.clearIndependentItemColorData = function(item) {
    if (
        !item ||
        !item.baseItemId ||
        typeof $gameSystem === 'undefined' ||
        !$gameSystem
    ) {
        return false;
    }

    let property = '';
    if (item.wtypeId !== undefined) {
        property = '_drill_ITC_colorCode_Weapon';
    } else if (item.atypeId !== undefined) {
        property = '_drill_ITC_colorCode_Armor';
    } else {
        return false;
    }

    const table = $gameSystem[property];
    const id = Number(item.id);
    if (
        !table ||
        typeof table !== 'object' ||
        !Number.isInteger(id) ||
        id < 0
    ) {
        return false;
    }

    const hadRegistration =
        table[id] !== undefined &&
        table[id] !== null;
    delete table[id];

    if (Array.isArray(table)) {
        while (
            table.length > 0 &&
            (
                table[table.length - 1] === undefined ||
                table[table.length - 1] === null
            )
        ) {
            table.pop();
        }
    }

    return hadRegistration;
};

DataManager.clearIndependentItemOnGainEvalData = function(item) {
    if (
        !item ||
        !item.baseItemId ||
        typeof $gameParty === 'undefined' ||
        !$gameParty ||
        !$gameParty._onGainEvalFired
    ) {
        return false;
    }

    let prefix = '';
    if (item.wtypeId !== undefined) {
        prefix = 'w';
    } else if (item.atypeId !== undefined) {
        prefix = 'a';
    } else if (item.itypeId !== undefined) {
        prefix = 'i';
    } else {
        return false;
    }

    const id = Number(item.id);
    if (!Number.isInteger(id) || id < 0) return false;

    const key = `${prefix}${id}`;
    const table = $gameParty._onGainEvalFired;
    const hadRegistration = Object.prototype.hasOwnProperty.call(table, key);
    delete table[key];
    return hadRegistration;
};

DataManager.removeIndependentItem = function(item) {
    if (!item) return false;
    if (this.independentItemIsUsed(item)) return false;

    const container = this.getContainer(item);
    const database = this.getDatabase(item);
    const containerIndex = container.indexOf(item);
    const databaseIndex = database.indexOf(item);
    if (containerIndex < 0 && databaseIndex < 0) return false;

    if (containerIndex >= 0) container[containerIndex] = null;
    if (databaseIndex >= 0) database[databaseIndex] = null;
    this.clearIndependentItemColorData(item);
    this.clearIndependentItemOnGainEvalData(item);

    while (
        container.length > 0 &&
        (
            container[container.length - 1] === undefined ||
            container[container.length - 1] === null
        )
    ) {
        container.pop();
    }
    return true;
};

DataManager.independentItemIsUsed = function(item) {
    if ($gameParty.numItems(item) > 0) return false;
    for (var i = 0; i < $dataActors.length; ++i) {
      var actor = $gameActors.actor(i);
      if (!actor) continue;
      if (actor.equips().contains(item)) return true;
    }
    return false;
};

DataManager.getDatabase = function(item) {
    if (!item) return [];
    if (DataManager.isItem(item) || item.itypeId !== undefined) return $dataItems;
    if (DataManager.isWeapon(item) || item.wtypeId !== undefined) return $dataWeapons;
    if (DataManager.isArmor(item) || item.atypeId !== undefined) return $dataArmors;
    return [];
};

DataManager.getContainer = function(item) {
    if (!item) return [];
    if (DataManager.isItem(item) || item.itypeId !== undefined) return this._independentItems;
    if (DataManager.isWeapon(item) || item.wtypeId !== undefined) return this._independentWeapons;
    if (DataManager.isArmor(item) || item.atypeId !== undefined) return this._independentArmors;
    return [];
};

DataManager.getBaseItem = function(item) {
    if (!this.isIndependent(item)) return item;
    if (!item.baseItemId) return item;
    var baseItemId = item.baseItemId;
    var baseItem = this.getDatabase(item)[baseItemId];
    return baseItem;
};

//=============================================================================
// ItemManager
//=============================================================================

function ItemManager() {
    throw new Error('This is a static class');
};

ItemManager.setNewIndependentItem = function(baseItem, newItem) {
    newItem.baseItemId = baseItem.id;
    newItem.baseItemName = baseItem.name;
    newItem.baseItemPrice = baseItem.price;
    newItem.baseItemIconIndex = baseItem.iconIndex;
    newItem.namePrefix = '';
    newItem.nameSuffix = '';
    if (baseItem.setPriorityName) {
      newItem.priorityName = baseItem.name;
    } else {
      newItem.priorityName = '';
    }
    newItem.boostCount = 0;
    if (!Yanfly.Param.ItemNoteParse) newItem.note = '';
    const isIndependentObject = baseItem && (
        baseItem.itypeId !== undefined ||
        baseItem.wtypeId !== undefined ||
        baseItem.atypeId !== undefined
    );
    if (isIndependentObject) {
        newItem._templateFingerprint =
            DataManager.makeIndependentEquipTemplateFingerprint(baseItem);
    }
};

ItemManager.customizeNewIndependentItem = function(baseItem, newItem) {
    this.randomizeInitialItem(baseItem, newItem);
    this.updateItemName(newItem);
    // 尝试赋予红化效果，仅对武器生效
    if ($gameMap?.chahuiMapTemp?.switchRubedo) {
        dingk.Loot.applyRubedoToWeapon(newItem);
    } 
    // 每次生产独立物品时，根据 <颜色:N> 标签初始化物品等级（品质）属性。
    newItem.itemRank = this.getItemRankByColor(newItem);
};

// 物品颜色标签 -> 物品等级（品质）的对应关系：
//   无颜色标签 = 0 级
//   <颜色:16> = 1 级
//   <颜色:15> = 2 级
//   <颜色:14> = 3 级
//   <颜色:13> = 4 级
//   <颜色:10> = 5 级
ItemManager.colorRankTable = {
    16: 1,
    15: 2,
    14: 3,
    13: 4,
    1: 5
};

// 根据物品 meta 里的 <颜色:N> 标签计算物品等级，无标签或无法识别时返回 0。
ItemManager.getItemRankByColor = function(item) {
    if (!item) return 0;
    var meta = item.meta;
    // 独立物品实例会继承基础物品的 meta；若意外缺失则回退到基础数据。
    if (!meta && item.baseItemId) {
        var base = DataManager.getBaseItem(item);
        meta = base ? base.meta : null;
    }
    if (!meta) return 0;
    var color = parseInt(meta['颜色']);
    if (isNaN(color)) return 0;
    return ItemManager.colorRankTable[color] || 0;
};

// 通用读取接口：优先返回已初始化的 itemRank，
// 否则（例如旧存档里已存在的物品）即时根据颜色标签推算，方便随时检查。
DataManager.itemRank = function(item) {
    if (!item) return 0;
    if (item.itemRank !== undefined) return item.itemRank;
    return ItemManager.getItemRankByColor(item);
};

ItemManager.randomizeInitialItem = function(baseItem, newItem) {
    if ($gameTemp.varianceStock()) return;
    if (DataManager.isItem(baseItem)) {
      this.randomizeInitialEffects(baseItem, newItem);
    } else {
      this.randomizeInitialStats(baseItem, newItem);
    }
};

ItemManager.randomizeInitialEffects = function(baseItem, newItem) {
    if (baseItem.randomVariance <= 0) return;
    var randomValue = baseItem.randomVariance * 2 + 1;
    var offset = baseItem.randomVariance;
    newItem.effects.forEach(function(effect) {
      if (effect.code === Game_Action.EFFECT_RECOVER_HP) {
        if (effect.value1 !== 0) {
          var boost = Math.floor(Math.random() * randomValue - offset);
          effect.value1 += boost * 0.01;
          effect.value1 = parseFloat(effect.value1.toFixed(2));
          effect.value1 = effect.value1.clamp(0, 1);
        }
        if (effect.value2 !== 0) {
          effect.value2 += Math.floor(Math.random() * randomValue - offset);
        }
      }
      if (effect.code === Game_Action.EFFECT_RECOVER_MP) {
        if (effect.value1 !== 0) {
          var boost = Math.floor(Math.random() * randomValue - offset);
          effect.value1 += boost * 0.01;
          effect.value1 = parseFloat(effect.value1.toFixed(2));
          effect.value1 = effect.value1.clamp(0, 1);
        }
        if (effect.value2 !== 0) {
          effect.value2 += Math.floor(Math.random() * randomValue - offset);
        }
      }
    }, this);
};

ItemManager.randomizeInitialStats = function(baseItem, newItem) {
    if (baseItem.randomVariance <= 0) return;
    var randomValue = baseItem.randomVariance * 2 + 1;
    var offset = baseItem.randomVariance;
    for (var i = 0; i < 8; ++i) {
      if (newItem.params[i] === 0) continue;
      newItem.params[i] += Math.floor(Math.random() * randomValue - offset);
      if (!Yanfly.Param.ItemNegVar && baseItem.params[i] >= 0) {
        newItem.params[i] = Math.max(newItem.params[i], 0);
      }
    }
};

ItemManager.setBaseName = function(item, value) {
    item.baseItemName = value;
};

ItemManager.setNamePrefix = function(item, value) {
    item.namePrefix = value;
    if (eval(Yanfly.Param.ItemNameSpacing) && item.namePrefix.length > 0) {
      item.namePrefix = item.namePrefix + ' ';
    }
};

ItemManager.setNameSuffix = function(item, value) {
    item.nameSuffix = value;
    if (eval(Yanfly.Param.ItemNameSpacing) && item.nameSuffix.length > 0) {
      item.nameSuffix = ' ' + item.nameSuffix;
    }
};

ItemManager.setPriorityName = function(item, value) {
    item.priorityName = value;
};

ItemManager.updateItemName = function(item) {
	
    if (item.priorityName && item.priorityName.length > 0) {
      item.name = item.priorityName;
      return;
    }
    var prefix = item.namePrefix || '';
    var baseName = item.baseItemName || '';
    var suffix = item.nameSuffix || '';
    var boostCount = item.boostCount || 0;
    var fmt = Yanfly.Param.ItemBoostFmt;
    var boostText = fmt.format(Yanfly.Util.toGroup(boostCount))
    if (boostText === fmt.format(0)) {
      boostText = '';
    } else if (eval(Yanfly.Param.ItemNameSpacing)) {
      boostText = ' ' + boostText;
    }
    fmt = Yanfly.Param.ItemNameFmt;
    item.name = fmt.format(prefix, baseName, suffix, boostText);

};

ItemManager.increaseItemBoostCount = function(item, value) {
    value = value || 1;
    if (!item.boostCount) item.boostCount = 0;
    item.boostCount += value;
    this.updateItemName(item);
};

ItemManager.onCreationEval = function(baseItem, newItem) {
    var item = newItem;
    if (item.onCreationEval === '') return;
    var weapon = item;
    var armor = item;
    var baseWeapon = baseItem;
    var baseArmor = baseItem;
    var s = $gameSwitches._data;
    var v = $gameVariables._data;
    var code = item.onCreationEval;
    try {
      eval(code);
    } catch (e) {
      Yanfly.Util.displayError(e, code, 'ITEM CREATION CUSTOM CODE ERROR');
    }
    item.onCreationEval = '';
};

//=============================================================================
// Game_Temp
//=============================================================================

Game_Temp.prototype.enableVarianceStock = function() {
    this._independentStock = true;
};

Game_Temp.prototype.disableVarianceStock = function() {
    this._independentStock = false;
};

Game_Temp.prototype.varianceStock = function() {
    return this._independentStock;
};

//=============================================================================
// Game_Actor
//=============================================================================

Yanfly.Item.Game_Actor_setup = Game_Actor.prototype.setup;
Game_Actor.prototype.setup = function(actorId) {
    Yanfly.Item.Game_Actor_setup.call(this, actorId);
    if ($gameTemp._initializeStartingMemberEquipment) return;
    this.initIndependentEquips($dataActors[actorId].equips);
};

Game_Actor.prototype.initIndependentEquips = function(equips) {
    var equips = this.convertInitEquips(equips);
    this.equipInitIndependentEquips(equips);
    this.releaseUnequippableItems(true);
    this.recoverAll();
    this.refresh();
};

Game_Actor.prototype.convertInitEquips = function(equips) {
    var items = [];
    for (var i = 0; i < equips.length; ++i) {
      var equipId = equips[i];
      if (equipId <= 0) continue;
      var equipType = $dataSystem.equipTypes[i + 1];
      if (equipType === $dataSystem.equipTypes[1] ||
      (i === 1 && this.isDualWield())) {
        var equip = $dataWeapons[equipId];
      } else {
        var equip = $dataArmors[equipId];
      }
      items.push(equip);
    }
    return items;
};

Game_Actor.prototype.equipInitIndependentEquips = function(equips) {
    var slots = this.equipSlots();
    var maxSlots = slots.length;
    this._equips = [];
    for (var i = 0; i < maxSlots; ++i) {
      this._equips[i] = new Game_Item();
    }
    for (var i = 0; i < maxSlots; ++i) {
      var slotType = slots[i];
      var equip = this.grabInitEquips(equips, slotType);
      if (DataManager.isIndependent(equip) && this.canEquip(equip)) {
        var array = $gameParty.gainIndependentItem(equip, 1)
        if (array instanceof Array) {
          newItem = array[0];
          this.changeEquip(i, newItem);
        }
      } else if (this.canEquip(equip)) {
        this._equips[i].setObject(equip);
      }
    }
};

Game_Actor.prototype.grabInitEquips = function(equips, slotType) {
    var item = null;
    for (var i = 0; i < equips.length; ++i) {
      var equip = equips[i];
      if (!equip) continue;
      if (slotType === 1 && DataManager.isWeapon(equip)) {
        item = equip;
        break;
      } else if (equip.etypeId === slotType) {
        item = equip;
        break;
      }
    }
    if (item) equips[i] = null;
    return item;
};

Yanfly.Item.Game_Actor_hasWeapon = Game_Actor.prototype.hasWeapon;
Game_Actor.prototype.hasWeapon = function(weapon) {
    if (this.hasBaseItem(weapon)) return true;
    return Yanfly.Item.Game_Actor_hasWeapon.call(this, weapon);
};

Yanfly.Item.Game_Actor_hasArmor = Game_Actor.prototype.hasArmor;
Game_Actor.prototype.hasArmor = function(armor) {
    if (this.hasBaseItem(armor)) return true;
    return Yanfly.Item.Game_Actor_hasArmor.call(this, armor);
};

Game_Actor.prototype.hasBaseItem = function(baseItem) {
    if (!DataManager.isIndependent(baseItem)) return false;
    var type = (DataManager.isWeapon(baseItem)) ? 'weapon' : 'armor';
    for (var i = 0; i < this.equips().length; ++i) {
      var equip = this.equips()[i];
      if (!equip) continue;
      if (!equip.baseItemId) continue;
      if (DataManager.isWeapon(equip) && type === 'weapon') {
        if (equip.baseItemId === baseItem.id) return true;
      } else if (DataManager.isArmor(equip) && type === 'armor') {
        if (equip.baseItemId === baseItem.id) return true;
      }
    }
    return false;
};

//更换装备
Yanfly.Item.Game_Actor_changeEquipById = Game_Actor.prototype.changeEquipById;
Game_Actor.prototype.changeEquipById = function(etypeId, itemId) {
    if (itemId > 0) {
      var slotId = etypeId - 1;
      if (this.equipSlots()[slotId] === 1) {
        var baseItem = $dataWeapons[itemId];
      } else {
        var baseItem = $dataArmors[itemId];
      }
      if (!$gameParty.hasItem(baseItem)) {
        $gameParty.gainItem(baseItem, 1);
      }
      if (DataManager.isIndependent(baseItem)) {
        //if (this.hasBaseItem(baseItem)) return;
        var item = $gameParty.getMatchingBaseItem(baseItem, false);
        if (item === null) {
          $gameTemp.enableVarianceStock();
          $gameParty.gainItem(baseItem, 1);
          $gameTemp.disableVarianceStock();
          item = $gameParty.getMatchingBaseItem(baseItem, false);
        }
        this.changeEquip(slotId, item);
        return;
      }
    }
    Yanfly.Item.Game_Actor_changeEquipById.call(this, etypeId, itemId)
};

Game_Actor.prototype.unequipItem = function(item) {
    for (var i = 0; i < this.equips().length; ++i) {
      var equip = this.equips()[i];
      if (!equip) continue;
      if (equip !== item) continue;
      this.changeEquip(i, null);
    }
};

//=============================================================================
// Game_Party
//=============================================================================

Yanfly.Item.Game_Party_setupStartingMembers =
    Game_Party.prototype.setupStartingMembers;
Game_Party.prototype.setupStartingMembers = function() {
    Yanfly.Item.Game_Party_setupStartingMembers.call(this);
    $gameTemp.enableVarianceStock();
    this.initActorEquips();
    $gameTemp.disableVarianceStock();
};

Game_Party.prototype.initActorEquips = function() {
    $gameTemp._initializeStartingMemberEquipment = true;
    for (var i = 0; i < $dataActors.length; ++i) {
      var actor = $gameActors.actor(i);
      if (actor) {
        var baseActor = $dataActors[i];
        actor.initIndependentEquips(baseActor.equips);
      }
    }
    $gameTemp._initializeStartingMemberEquipment = undefined;
};

Yanfly.Item.Game_Party_gainItem = Game_Party.prototype.gainItem;
Game_Party.prototype.gainItem = function(item, amount, includeEquip) {
    var before = DataManager.isIndependent(item) ? -1 : this.numItems(item);
    if (DataManager.isIndependent(item)) {
      this.gainIndependentItem(item, amount, includeEquip);
    } else {
      Yanfly.Item.Game_Party_gainItem.call(this, item, amount, includeEquip);
    }
    if ((before === 0 || item.animationId > 0) && this.numItems(item) > 0) {
      this.runOnGainEval(item);
    }
};

Game_Party.prototype.runOnGainEval = function(item) {
    if (!item || !item.onGainEval || item.onGainEval === '') return;
    if (!this._onGainEvalFired) this._onGainEvalFired = {};
    var key = (DataManager.isItem(item) ? 'i' : DataManager.isWeapon(item) ? 'w' : 'a') + item.id;
    if (this._onGainEvalFired[key] && item.animationId == 0) return;
    this._onGainEvalFired[key] = true;
    var s = $gameSwitches._data;
    var v = $gameVariables._data;
    var code = item.onGainEval;
    try {
      eval(code);
    } catch (e) {
      Yanfly.Util.displayError(e, code, 'ITEM ON GAIN CUSTOM CODE ERROR');
    }
};

Game_Party.prototype.gainIndependentItem = function(item, amount, includeEquip) {
    var arr = [];
    if (amount > 0) {
      for (var i = 0; i < amount; ++i) {
        var newItem = DataManager.registerNewItem(item);
        this.registerNewItem(item, newItem);
        arr.push(newItem);
      }
    } else if (amount < 0) {
      amount = Math.abs(amount);
      for (var i = 0; i < amount; ++i) {
        if (item.baseItemId) {
          this.removeIndependentItem(item, includeEquip);
        } else if (DataManager.isIndependent(item)) {
          var target = $gameParty.getMatchingBaseItem(item, includeEquip);
          if (target !== null) this.removeIndependentItem(target, includeEquip);
        } else {
          this.removeBaseItem(item, includeEquip);
        }
      }
    }
    return arr;
};

Game_Party.prototype.getIndependentItemTypeMax = function(item) {
    if (!item) return 0;
    if (DataManager.isItem(item)) return Yanfly.Param.ItemMaxItems;
    if (DataManager.isWeapon(item)) return Yanfly.Param.ItemMaxWeapons;
    if (DataManager.isArmor(item)) return Yanfly.Param.ItemMaxArmors;
};

Game_Party.prototype.getIndependentItemTypeCur = function(item) {
    if (!item) return 0;
    if (DataManager.isItem(item)) return this.items().length;
    if (DataManager.isWeapon(item)) return this.weapons().length;
    if (DataManager.isArmor(item)) return this.armors().length;
};

Game_Party.prototype.registerNewItem = function(baseItem, newItem) {
    var container = this.itemContainer(baseItem);
    if (container) {
      var lastNumber = this.numItems(newItem);
      container[newItem.id] = 1;
    }
};

Game_Party.prototype.removeIndependentItem = function(item, includeEquip) {
    if (includeEquip && this.checkItemIsEquipped(item)) {
      for (var i = 1; i < $gameActors._data.length; ++i) {
        var actor = $gameActors.actor(i);
        if (!actor) continue;
        if (!actor.equips().contains(item)) continue;
        actor.unequipItem(item);
      }
    }
    var container = this.itemContainer(item);
    container[item.id] = 0;
    if (container[item.id] <= 0) delete container[item.id];

};

Game_Party.prototype.removeBaseItem = function(item, includeEquip) {
    var container = this.itemContainer(item);
    container[item.id]--;
    if (container[item.id] <= 0) delete container[item.id];
    if (includeEquip) this.discardMembersEquip(item, -1);
};

Game_Party.prototype.getMatchingBaseItem = function(baseItem, equipped) {
    if (!baseItem) return null;
    if (DataManager.isItem(baseItem)) var group = this.items();
    if (DataManager.isWeapon(baseItem)) var group = this.weapons();
    if (DataManager.isArmor(baseItem)) var group = this.armors();
    if (equipped) {
      for (var a = 0; a < this.members().length; ++a) {
        var actor = this.members()[a];
        if (!actor) continue;
        if (DataManager.isWeapon(baseItem)) {
          group = group.concat(actor.weapons());
        } else if (DataManager.isArmor(baseItem)) {
          group = group.concat(actor.armors());
        }
      }
    }
    var baseItemId = baseItem.id;
    for (var i = 0; i < group.length; ++i) {
      var item = group[i];
      if (!item) continue;
      if (!item.baseItemId) continue;
      if (item.baseItemId !== baseItemId) continue;
      return item;
    }
    return null;
};

Game_Party.prototype.checkItemIsEquipped = function(item) {
    for (var i = 1; i < $gameActors._data.length; ++i) {
      var actor = $gameActors.actor(i);
      if (!actor) continue;
      if (actor.equips().contains(item)) return true;
    }
    return false;
};

Yanfly.Item.Game_Party_items = Game_Party.prototype.items;
Game_Party.prototype.items = function() {
    var results = Yanfly.Item.Game_Party_items.call(this);
    results.sort(this.independentItemSort);
    return results;
};

Yanfly.Item.Game_Party_weapons = Game_Party.prototype.weapons;
Game_Party.prototype.weapons = function() {
    var results = Yanfly.Item.Game_Party_weapons.call(this);
    results.sort(this.independentItemSort);
    return results;
};

Yanfly.Item.Game_Party_armors = Game_Party.prototype.armors;
Game_Party.prototype.armors = function() {
    var results = Yanfly.Item.Game_Party_armors.call(this);
    results.sort(this.independentItemSort);
    return results;
};

/*
Game_Party.prototype.independentItemSort = function(a, b) {
    var aa = (a.baseItemId) ? a.baseItemId : a.id;
    var bb = (b.baseItemId) ? b.baseItemId : b.id;
    if (aa < bb) return -1;
    if (aa >= bb) return 1;
    return 0;
};
*/

Game_Party.prototype.independentItemSort = function(a, b) {
    if (!a || !b) return 0; // 修复null异常
    var aa = (a.baseItemId) ? a.baseItemId : a.id;
    var bb = (b.baseItemId) ? b.baseItemId : b.id;
    return aa - bb;
};

Yanfly.Item.Game_Party_maxItems = Game_Party.prototype.maxItems;
Game_Party.prototype.maxItems = function(item) {
    if (DataManager.isIndependent(item)) return 1;
    return Yanfly.Item.Game_Party_maxItems.call(this, item);
};

Yanfly.Item.Game_Party_hasItem = Game_Party.prototype.hasItem;
Game_Party.prototype.hasItem = function(item, includeEquip) {
    if (DataManager.isIndependent(item)) {
      if (this.numIndependentItems(item) > 0) return true;
    }
    return Yanfly.Item.Game_Party_hasItem.call(this, item, includeEquip);
};

Yanfly.Item.Game_Party_isAnyMemberEquipped =
    Game_Party.prototype.isAnyMemberEquipped;
Game_Party.prototype.isAnyMemberEquipped = function(item) {
    if (DataManager.isIndependent(item)) {
      for (var i = 0; i < this.members().length; ++i) {
        var actor = this.members()[i];
        if (!actor) continue;
        if (actor.hasBaseItem(item)) return true;
      }
    }
    return Yanfly.Item.Game_Party_isAnyMemberEquipped.call(this, item);
};

Game_Party.prototype.numIndependentItems = function(baseItem) {
    var value = 0;
    if (!DataManager.isIndependent(baseItem)) return this.numItems(baseItem);
    var id = baseItem.id;
    if (DataManager.isItem(baseItem)) var group = this.items();
    if (DataManager.isWeapon(baseItem)) var group = this.weapons();
    if (DataManager.isArmor(baseItem)) var group = this.armors();
    for (var i = 0; i < group.length; ++i) {
      var item = group[i];
      if (!item) continue;
      if (item.baseItemId && item.baseItemId === id) value += 1;
    }
    return value;
};

Game_Party.prototype.clearAllMatchingBaseItems = function(baseItem, equipped) {
  if (!Imported.YEP_ItemCore) return;
  for (;;) {
    var item = this.getMatchingBaseItem(baseItem, equipped);
    if (item) {
      this.removeIndependentItem(item, equipped);
      DataManager.removeIndependentItem(item);
    } else {
      break;
    }
  }
};

//=============================================================================
// Game_Interpreter
//=============================================================================

Yanfly.Item.Game_Interpreter_pluginCommand =
    Game_Interpreter.prototype.pluginCommand;
Game_Interpreter.prototype.pluginCommand = function(command, args) {
    Yanfly.Item.Game_Interpreter_pluginCommand.call(this, command, args)
    if (command === 'EnableVarianceStock') $gameTemp.enableVarianceStock();
    if (command === 'DisableVarianceStock') $gameTemp.disableVarianceStock();
};

Yanfly.Item.Game_Interpreter_gDO = Game_Interpreter.prototype.gameDataOperand;
Game_Interpreter.prototype.gameDataOperand = function(type, param1, param2) {
  switch (type) {
  case 0:
    return $gameParty.numIndependentItems($dataItems[param1]);
    break;
  case 1:
    return $gameParty.numIndependentItems($dataWeapons[param1]);
    break;
  case 2:
    return $gameParty.numIndependentItems($dataArmors[param1]);
    break;
  default:
    return Yanfly.Item.Game_Interpreter_gDO.call(this, type, param1, param2);
    break;
  }
};

//=============================================================================
// Window_Base
//=============================================================================

Yanfly.Item.Window_Base_drawItemName = Window_Base.prototype.drawItemName;
Window_Base.prototype.drawItemName = function(item, wx, wy, ww) {
    ww = ww || 312;
    this.setItemTextColor(item);
    Yanfly.Item.Window_Base_drawItemName.call(this, item, wx, wy, ww);
    this._resetTextColor = undefined;
    this.resetTextColor();
};

Window_Base.prototype.setItemTextColor = function(item) {
    if (!item) return;
    if (item.textColor === undefined) return;
    this._resetTextColor = item.textColor;
};

Yanfly.Item.Window_Base_normalColor = Window_Base.prototype.normalColor;
Window_Base.prototype.normalColor = function() {
    if (this._resetTextColor !== undefined) {
      return this.textColor(this._resetTextColor);
    }
    return Yanfly.Item.Window_Base_normalColor.call(this);
};

//=============================================================================
// Window_ItemList
//=============================================================================

Yanfly.Item.Window_ItemList_makeItemList =
    Window_ItemList.prototype.makeItemList;
Window_ItemList.prototype.makeItemList = function() {
    Yanfly.Item.Window_ItemList_makeItemList.call(this);
    if (SceneManager._scene instanceof Scene_Item) this.listEquippedItems();
};

Window_ItemList.prototype.listEquippedItems = function() {
    if (!Yanfly.Param.ItemShEquipped) return;
    var results = [];
    for (var a = 0; a < $gameParty.members().length; ++a) {
      var actor = $gameParty.members()[a];
      if (!actor) continue;
      for (var i = 0; i < actor.equips().length; ++i) {
        var equip = actor.equips()[i];
        if (!equip) continue;
        if (!equip.baseItemId) continue;
        if (this.includes(equip)) results.push(equip);
      }
    }
    this._data = results.concat(this._data);
};

Yanfly.Item.Window_ItemList_drawItemNumber =
    Window_ItemList.prototype.drawItemNumber;
Window_ItemList.prototype.drawItemNumber = function(item, dx, dy, dw) {
    if (DataManager.isIndependent(item)) {
      this.drawItemCarryNumber(item, dx, dy, dw);
      return;
    }
    Yanfly.Item.Window_ItemList_drawItemNumber.call(this, item, dx, dy, dw);
};

Window_ItemList.prototype.drawItemCarryNumber = function(item, dx, dy, dw) {
    if (DataManager.isItem(item)) {
      var index = $gameParty.items().indexOf(item);
    } else if (DataManager.isWeapon(item)) {
      var index = $gameParty.weapons().indexOf(item);
    } else if (DataManager.isArmor(item)) {
      var index = $gameParty.armors().indexOf(item);
    }
    if (index < 0) return this.drawEquippedActor(item, dx, dy, dw);
    index += 1;
    var max = $gameParty.getIndependentItemTypeMax(item);
    var fmt = Yanfly.Param.ItemCarryFmt;
    var text = fmt.format(Yanfly.Util.toGroup(index), Yanfly.Util.toGroup(max));
    if (Yanfly.Param.ItemQuantitySize) {
      this.contents.fontSize = Yanfly.Param.ItemQuantitySize;
    }
    if (index > max) {
      this.changeTextColor(this.powerDownColor());
    } else if (index === max) {
      this.changeTextColor(this.crisisColor());
    } else {
      this.changeTextColor(this.normalColor());
    }
    this.drawText(text, dx, dy, dw, 'right');
    this.resetFontSettings();
};

Window_ItemList.prototype.drawEquippedActor = function(item, dx, dy, dw) {
    var carrier = null;
    for (var a = 0; a < $gameParty.members().length; ++a) {
      var actor = $gameParty.members()[a];
      if (!actor) continue;
      if (actor.equips().contains(item)) carrier = actor;
    };
    if (Yanfly.Param.ItemQuantitySize) {
      this.contents.fontSize = Yanfly.Param.ItemQuantitySize;
    }
    var text = carrier.name();
    this.drawText(text, dx, dy, dw, 'right');
    this.resetFontSettings();
};

//=============================================================================
// Window_EquipItem
//=============================================================================

Yanfly.Item.Window_EquipItem_includes = Window_EquipItem.prototype.includes;
Window_EquipItem.prototype.includes = function(item) {
    if (this._actor && item !== null) {
      if (!item) return false;
    }
    return Yanfly.Item.Window_EquipItem_includes.call(this, item);
};

//=============================================================================
// Window_ShopBuy
//=============================================================================

Yanfly.Item.Window_ShopBuy_isEnabled = Window_ShopBuy.prototype.isEnabled;
Window_ShopBuy.prototype.isEnabled = function(item) {
    if (DataManager.isIndependent(item)) {
      var typeMax = $gameParty.getIndependentItemTypeMax(item);
      var typeCur = $gameParty.getIndependentItemTypeCur(item);
      if (typeCur >= typeMax) return false;
    }
    return Yanfly.Item.Window_ShopBuy_isEnabled.call(this, item);
};

//=============================================================================
// Window_ShopStatus
//=============================================================================

Yanfly.Item.Window_ShopStatus_drawPossession =
    Window_ShopStatus.prototype.drawPossession;
Window_ShopStatus.prototype.drawPossession = function(x, y) {
    if (DataManager.isIndependent(this._item)) {
      return this.drawIndependentPossession(x, y);
    }
    Yanfly.Item.Window_ShopStatus_drawPossession.call(this, x, y);
};

Window_ShopStatus.prototype.drawIndependentPossession = function(x, y) {
    var width = this.contents.width - this.textPadding() - x;
    var baseItem = DataManager.getBaseItem(this._item);
    var value = $gameParty.numIndependentItems(baseItem);
    value = Yanfly.Util.toGroup(value);
    var possessionWidth = this.textWidth(value);
    this.changeTextColor(this.systemColor());
    this.drawText(TextManager.possession, x, y, width - possessionWidth);
    this.resetTextColor();
    this.drawText(value, x, y, width, 'right');
};

//=============================================================================
// Scene_Equip
//=============================================================================

Yanfly.Item.Scene_Equip_refreshActor = Scene_Equip.prototype.refreshActor;
Scene_Equip.prototype.refreshActor = function() {
    this.actor().releaseUnequippableItems();
    Yanfly.Item.Scene_Equip_refreshActor.call(this);
};

//=============================================================================
// Scene_Shop
//=============================================================================

Yanfly.Item.Scene_Shop_doBuy = Scene_Shop.prototype.doBuy;
Scene_Shop.prototype.doBuy = function(number) {
    $gameTemp.enableVarianceStock();
    Yanfly.Item.Scene_Shop_doBuy.call(this, number);
    $gameTemp.disableVarianceStock();
};

Yanfly.Item.Scene_Shop_doSell = Scene_Shop.prototype.doSell;
Scene_Shop.prototype.doSell = function(number) {
    Yanfly.Item.Scene_Shop_doSell.call(this, number);
    if (!DataManager.isIndependent(this._item)) return;
    DataManager.removeIndependentItem(this._item);
};

//=============================================================================
// Scene_Item 1.6.0 Code Suppress
//=============================================================================

if (Utils.RPGMAKER_VERSION && Utils.RPGMAKER_VERSION >= "1.6.0") {

Scene_Item.prototype.update = function() {
  Scene_ItemBase.prototype.update.call(this);
};

}; // Utils.RPGMAKER_VERSION && Utils.RPGMAKER_VERSION >= "1.6.0"

//=============================================================================
// Scene_Item Update
//=============================================================================

if (Yanfly.Param.ItemSceneItem) {

//=============================================================================
// Window_ItemCategory
//=============================================================================

Yanfly.Item.Window_ItemCategory_windowWidth =
    Window_ItemCategory.prototype.windowWidth;
Window_ItemCategory.prototype.windowWidth = function() {
    if (SceneManager._scene instanceof Scene_Item) return 240;
    return Yanfly.Item.Window_ItemCategory_windowWidth.call(this);
};

Yanfly.Item.Window_ItemCategory_numVisibleRows =
    Window_ItemCategory.prototype.numVisibleRows;
Window_ItemCategory.prototype.numVisibleRows = function() {
    if (SceneManager._scene instanceof Scene_Item) return 4;
    return Yanfly.Item.Window_ItemCategory_numVisibleRows.call(this);
};

Yanfly.Item.Window_ItemCategory_maxCols = Window_ItemCategory.prototype.maxCols;
Window_ItemCategory.prototype.maxCols = function() {
    if (SceneManager._scene instanceof Scene_Item) return 1;
    return Yanfly.Item.Window_ItemCategory_maxCols.call(this);
};

Yanfly.Item.Window_ItemCategory_itemTextAlign =
    Window_ItemCategory.prototype.itemTextAlign;
Window_ItemCategory.prototype.itemTextAlign = function() {
    if (SceneManager._scene instanceof Scene_Item) {
      return Yanfly.Param.ItemCmdAlign;
    }
    return Yanfly.Item.Window_ItemCategory_itemTextAlign.call(this);
};

//=============================================================================
// Window_ItemList
//=============================================================================

Yanfly.Item.Window_ItemList_initialize = Window_ItemList.prototype.initialize;
Window_ItemList.prototype.initialize = function(x, y, width, height) {
    if (SceneManager._scene instanceof Scene_Item) {
      width = Graphics.boxWidth / 2;
    }
    Yanfly.Item.Window_ItemList_initialize.call(this, x, y, width, height);
};

Yanfly.Item.Window_ItemList_maxCols = Window_ItemList.prototype.maxCols;
Window_ItemList.prototype.maxCols = function() {
    if (SceneManager._scene instanceof Scene_Item) return 1;
    return Yanfly.Item.Window_ItemList_maxCols.call(this);
};

Yanfly.Item.Window_ItemList_isEnabled = Window_ItemList.prototype.isEnabled;
Window_ItemList.prototype.isEnabled = function(item) {
    if (!item) return false;
    if (SceneManager._scene instanceof Scene_Item) return true;
    return Yanfly.Item.Window_ItemList_isEnabled.call(this, item);
};

Window_ItemList.prototype.setStatusWindow = function(statusWindow) {
    this._statusWindow = statusWindow;
    this.update();
};

Window_ItemList.prototype.setInfoWindow = function(infoWindow) {
    this._infoWindow = infoWindow;
    this.update();
};

Yanfly.Item.Window_ItemList_updateHelp = Window_ItemList.prototype.updateHelp;
Window_ItemList.prototype.updateHelp = function() {
	// 先跑 Info Eval（只在选中变化时跑一次）
	if (this._lastInfoEvalItem !== this._index) {
	  this._lastInfoEvalItem = this._index;
	  let item = this.item();
	  runInfoEvalWithItemThis(item); // 这里保持 this=道具本身
	}	
	
    Yanfly.Item.Window_ItemList_updateHelp.call(this);
    if (SceneManager._scene instanceof Scene_Item && this._statusWindow) {
      this._statusWindow.setItem(this.item());
    }
    if (SceneManager._scene instanceof Scene_Item && this._infoWindow) {
      this._infoWindow.setItem(this.item());
    }
};

function runInfoEvalWithItemThis(item) {
	if (!item) return;

	// 保持与 YEP 原逻辑一致：从 base item 继承 infoEval :contentReference[oaicite:2]{index=2}
	if (item.infoEval === undefined) {
	  item.infoEval = DataManager.getBaseItem(item).infoEval;
	}
	if (!item.infoEval) return;

	// 保持与 YEP 原 preInfoEval 提供的局部变量一致 :contentReference[oaicite:3]{index=3}
	var weapon = item;
	var armor  = item;
	var s = $gameSwitches._data;
	var v = $gameVariables._data;

	var code = item.infoEval;

	try {
	  // 关键：让 this = item，同时也提供 item/weapon/armor/s/v 这些局部变量
	  var fn = new Function('item', 'weapon', 'armor', 's', 'v', code);
	  fn.call(item, item, weapon, armor, s, v);
	} catch (e) {
	  // 用 YEP 的报错显示方式更友好
	  if (window.Yanfly && Yanfly.Util && Yanfly.Util.displayError) {
		Yanfly.Util.displayError(e, code, 'ITEMLIST ON-SELECT INFO EVAL ERROR');
	  } else {
		console.error(e, code);
	  }
	}
}

//=============================================================================
// Window_ItemStatus
//=============================================================================

function Window_ItemStatus() {
    this.initialize.apply(this, arguments);
}

Window_ItemStatus.prototype = Object.create(Window_Base.prototype);
Window_ItemStatus.prototype.constructor = Window_ItemStatus;

Window_ItemStatus.prototype.initialize = function(x, y, width, height) {
    Window_Base.prototype.initialize.call(this, x, y, width, height);
    this._item = null;
    this.deactivate();
    this.refresh();
};

Window_ItemStatus.prototype.setItem = function(item) {
    if (this._item === item) return;
    this._item = item;
    this.refresh();
};

Window_ItemStatus.prototype.refresh = function() {
    this.contents.clear();
    this.drawDarkRectEntries();
    if (!this._item) return;
    this.contents.fontSize = Yanfly.Param.ItemFontSize;
    this.drawItemEntry();
};

Window_ItemStatus.prototype.drawDarkRectEntries = function() {
    var rect = new Rectangle();
    if (Yanfly.Param.ItemShowIcon) {
      rect.width = Window_Base._faceWidth;
      rect.height = Window_Base._faceHeight;
      this.drawDarkRect(rect.x, rect.y, rect.width, rect.height);
      rect.width = (this.contents.width - Window_Base._faceWidth) / 2;
    } else {
      rect.width = this.contents.width / 2;
    }
    rect.height = this.lineHeight();
    for (var i = 0; i < 8; ++i) {
      rect = this.getRectPosition(rect, i);
      this.drawDarkRect(rect.x, rect.y, rect.width, rect.height);
    }
};

Window_ItemStatus.prototype.drawDarkRect = function(dx, dy, dw, dh) {
    var color = this.gaugeBackColor();
    this.changePaintOpacity(false);
    this.contents.fillRect(dx + 1, dy + 1, dw - 2, dh - 2, color);
    this.changePaintOpacity(true);
};

Window_ItemStatus.prototype.getRectPosition = function(rect, i) {
    if (i % 2 === 0) {
      if (Yanfly.Param.ItemShowIcon) {
        rect.x = Window_Base._faceWidth;
      } else {
        rect.x = 0;
      }
      rect.y = i / 2 * this.lineHeight();
    } else {
      if (Yanfly.Param.ItemShowIcon) {
        rect.x = Window_Base._faceWidth + rect.width;
      } else {
        rect.x = rect.width;
      }
    }
    return rect;
};

Window_ItemStatus.prototype.drawItemEntry = function() {
    var item = this._item;
    if (Yanfly.Param.ItemShowIcon) this.drawItemIcon(item);
    if (DataManager.isItem(item)) this.drawItemInfo(item);
    if (DataManager.isWeapon(item)) this.drawEquipInfo(item);
    if (DataManager.isArmor(item)) this.drawEquipInfo(item);
};

Window_ItemStatus.prototype.drawItemIcon = function() {
    this.drawLargeIcon();
};

Window_ItemStatus.prototype.drawLargeIcon = function() {
    var iconIndex = this._item.iconIndex;
    var bitmap = ImageManager.loadSystem('IconSet');
    var pw = Window_Base._iconWidth;
    var ph = Window_Base._iconHeight;
    var sx = iconIndex % 16 * pw;
    var sy = Math.floor(iconIndex / 16) * ph;
    var dw = Yanfly.Param.ItemIconSize;
    var dh = Yanfly.Param.ItemIconSize;
    var dx = (Window_Base._faceWidth - dw) / 2;
    var dy = (Window_Base._faceHeight - dh) / 2;
    this.contents._context.imageSmoothingEnabled = false;
    this.contents.blt(bitmap, sx, sy, pw, ph, dx, dy, dw, dh);
    this.contents._context.imageSmoothingEnabled = true;
};

Window_ItemStatus.prototype.drawEquipInfo = function(item) {
    var rect = new Rectangle();
    if (eval(Yanfly.Param.ItemShowIcon)) {
      rect.width = (this.contents.width - Window_Base._faceWidth) / 2;
    } else {
      rect.width = this.contents.width / 2;
    }
    for (var i = 0; i < 8; ++i) {
      rect = this.getRectPosition(rect, i);
      var dx = rect.x + this.textPadding();
      var dw = rect.width - this.textPadding() * 2;
      this.changeTextColor(this.systemColor());
      this.drawText(TextManager.param(i), dx, rect.y, dw);
      this.changeTextColor(this.paramchangeTextColor(item.params[i]));
      var text = Yanfly.Util.toGroup(item.params[i]);
      if (item.params[i] >= 0) text = '+' + text;
      if (text === '+0') this.changePaintOpacity(false);
      this.drawText(text, dx, rect.y, dw, 'right');
      this.changePaintOpacity(true);
    }
};

Window_ItemStatus.prototype.drawItemInfo = function(item) {
    var rect = new Rectangle();
    if (eval(Yanfly.Param.ItemShowIcon)) {
      rect.width = (this.contents.width - Window_Base._faceWidth) / 2;
    } else {
      rect.width = this.contents.width / 2;
    }
    for (var i = 0; i < 8; ++i) {
      rect = this.getRectPosition(rect, i);
      var dx = rect.x + this.textPadding();
      var dw = rect.width - this.textPadding() * 2;
      this.changeTextColor(this.systemColor());
      var text = this.getItemInfoCategory(i);
      this.drawText(text, dx, rect.y, dw);
      this.drawItemData(i, dx, rect.y, dw);
    }
};

Window_ItemStatus.prototype.getItemInfoCategory = function(i) {
    var fmt = Yanfly.Param.ItemRecoverFmt;
    if (i === 0) return fmt.format(TextManager.param(0));
    if (i === 1) return fmt.format(TextManager.hp);
    if (i === 2) return fmt.format(TextManager.param(1));
    if (i === 3) return fmt.format(TextManager.mp);
    if (i === 4) return Yanfly.Param.ItemAddState;
    if (i === 5) return Yanfly.Param.ItemRemoveState;
    if (i === 6) return Yanfly.Param.ItemAddBuff;
    if (i === 7) return Yanfly.Param.ItemRemoveBuff;
    return '';
};

Window_ItemStatus.prototype.drawItemData = function(i, dx, dy, dw) {
    if (!this._item) return;
    var effect;
    var value = '---';
    var pre = '';
    var text = '';
    var icons = [];
    if (i === 0) {
      effect = this.getEffect(Game_Action.EFFECT_RECOVER_HP);
      value = (effect) ? effect.value1 : '---';
      if (value === 0) value = '---';
      if (value !== '---' && value !== 0) value *= 100;
    }
    if (i === 1) {
      effect = this.getEffect(Game_Action.EFFECT_RECOVER_HP);
      value = (effect) ? effect.value2 : '---';
      if (value === 0) value = '---';
    }
    if (i === 2) {
      effect = this.getEffect(Game_Action.EFFECT_RECOVER_MP);
      value = (effect) ? effect.value1 : '---';
      if (value === 0) value = '---';
      if (value !== '---' && value !== 0) value *= 100;
    }
    if (i === 3) {
      effect = this.getEffect(Game_Action.EFFECT_RECOVER_MP);
      value = (effect) ? effect.value2 : '---';
      if (value === 0) value = '---';
    }
    if (i >= 4) {
      icons = this.getItemIcons(i, icons);
    }
    this.changeTextColor(this.normalColor());
    if (value === '---') {
      this.changePaintOpacity(false);
    } else if (i < 4) {
      if (value > 0) pre = '+';
      value = Yanfly.Util.toGroup(parseInt(value));
      if ([0, 2].contains(i)) text = '%';
    }
    if (icons.length > 0) {
      this.changePaintOpacity(true);
      dx = dx + dw - icons.length * Window_Base._iconWidth;
      dx += this.textPadding() - 2;
      for (var j = 0; j < icons.length; ++j) {
        var icon = icons[j];
        this.drawIcon(icon, dx, dy + 2);
        dx += Window_Base._iconWidth;
      }
    } else {
      text = pre + value + text;
      this.drawText(text, dx, dy, dw, 'right');
      this.changePaintOpacity(true);
    }
};

Window_ItemStatus.prototype.getEffect = function(code) {
    var targetEffect;
    this._item.effects.forEach(function(effect) {
      if (effect.code === code) targetEffect = effect;
    }, this);
    return targetEffect;
};

Window_ItemStatus.prototype.getItemIcons = function(i, array) {
    this._item.effects.forEach(function(effect) {
      if (i === 4 && effect.code === Game_Action.EFFECT_ADD_STATE) {
        var state = $dataStates[effect.dataId];
        if (state && state.iconIndex !== 0) array.push(state.iconIndex);
      }
      if (i === 5 && effect.code === Game_Action.EFFECT_REMOVE_STATE) {
        var state = $dataStates[effect.dataId];
        if (state && state.iconIndex !== 0) array.push(state.iconIndex);
      }
      if (i === 6 && effect.code === Game_Action.EFFECT_ADD_BUFF) {
        var icon = Game_BattlerBase.ICON_BUFF_START + effect.dataId;
        array.push(icon);
      }
      if (i === 6 && effect.code === Game_Action.EFFECT_ADD_DEBUFF) {
        var icon = Game_BattlerBase.ICON_DEBUFF_START + effect.dataId;
        array.push(icon);
      }
      if (i === 7 && effect.code === Game_Action.EFFECT_REMOVE_BUFF) {
        var icon = Game_BattlerBase.ICON_BUFF_START + effect.dataId;
        array.push(icon);
      }
      if (i === 7 && effect.code === Game_Action.EFFECT_REMOVE_DEBUFF) {
        var icon = Game_BattlerBase.ICON_DEBUFF_START + effect.dataId;
        array.push(icon);
      }
    }, this);
    array = array.slice(0, Yanfly.Param.ItemMaxIcons);
    return array;
};

//=============================================================================
// Window_ItemInfo
//=============================================================================

function Window_ItemInfo() {
    this.initialize.apply(this, arguments);
}

Window_ItemInfo.prototype = Object.create(Window_Base.prototype);
Window_ItemInfo.prototype.constructor = Window_ItemInfo;

Window_ItemInfo.prototype.initialize = function(x, y, width, height) {
    Window_Base.prototype.initialize.call(this, x, y, width, height);
    this._item = null;
    this.deactivate();
    this.refresh();
};

Window_ItemInfo.prototype.setItem = function(item) {
    if (this._item === item) return;
    this._item = item;
    this.refresh();
};

Window_ItemInfo.prototype.refresh = function() {
    this.contents.clear();
    var dy = 0;
    if (!this._item) return dy;
    this.preInfoEval();
    dy = this.drawPreItemInfo(dy);
    dy = this.drawItemInfo(dy);
    dy = this.drawItemInfoA(dy);
    dy = this.drawItemInfoB(dy);
    dy = this.drawItemInfoC(dy);
    dy = this.drawItemInfoD(dy);
    dy = this.drawItemInfoE(dy);
    return this.drawItemInfoF(dy);
};

Window_ItemInfo.prototype.preInfoEval = function() {
    var item = this._item;
    if (item.infoEval === undefined) {
      item.infoEval = DataManager.getBaseItem(item).infoEval;
    }
    if (item.infoEval === '') return;
    var weapon = this._item;
    var armor = this._item;
    var s = $gameSwitches._data;
    var v = $gameVariables._data;
    var code = item.infoEval;
    try {
      eval(code);
    } catch (e) {
      Yanfly.Util.displayError(e, code, 'ITEM WINDOW PRE INFO EVAL ERROR');
    }
};

Window_ItemInfo.prototype.drawPreItemInfo = function(dy) {
    return dy;
};

Window_ItemInfo.prototype.drawItemInfo = function(dy) {
    var dx = this.textPadding();
    var dw = this.contents.width - this.textPadding() * 2;
    this.resetFontSettings();
    this.drawItemName(this._item, dx, dy, dw);
    return dy + this.lineHeight();
};

Window_ItemInfo.prototype.drawItemInfoA = function(dy) {
    dy = this.drawInfoTextTop(dy);
    return dy;
};

Window_ItemInfo.prototype.drawItemInfoB = function(dy) {
    return dy;
};

Window_ItemInfo.prototype.drawItemInfoC = function(dy) {
    return dy;
};

Window_ItemInfo.prototype.drawItemInfoD = function(dy) {
    return dy;
};

Window_ItemInfo.prototype.drawItemInfoE = function(dy) {
    return dy;
};

Window_ItemInfo.prototype.drawItemInfoF = function(dy) {
    dy = this.drawInfoTextBottom(dy);
    return dy;
};

Window_ItemInfo.prototype.drawDarkRect = function(dx, dy, dw, dh) {
    var color = this.gaugeBackColor();
    this.changePaintOpacity(false);
    this.contents.fillRect(dx + 1, dy + 1, dw - 2, dh - 2, color);
    this.changePaintOpacity(true);
};

Window_ItemInfo.prototype.drawInfoTextTop = function(dy) {
    var item = this._item;
    if (item.infoTextTop === undefined) {
      item.infoTextTop = DataManager.getBaseItem(item).infoTextTop;
    }
    if (item.infoTextTop === '') return dy;
    var info = item.infoTextTop.split(/[\r\n]+/);
    for (var i = 0; i < info.length; ++i) {
      var line = info[i];
      this.resetFontSettings();
      this.drawTextEx(line, this.textPadding(), dy);
      dy += this.contents.fontSize + 8;
    }
    return dy;
};

Window_ItemInfo.prototype.drawInfoTextBottom = function(dy) {
    var item = this._item;
    if (item.infoTextBottom === undefined) {
      item.infoTextBottom = DataManager.getBaseItem(item).infoTextBottom;
    }
    if (item.infoTextBottom === '') return dy;
    var info = item.infoTextBottom.split(/[\r\n]+/);
    for (var i = 0; i < info.length; ++i) {
      var line = info[i];
      this.resetFontSettings();
      this.drawTextEx(line, this.textPadding(), dy);
      dy += this.contents.fontSize + 8;
    }
    return dy;
};

//=============================================================================
// Window_ItemActionCommand
//=============================================================================

function Window_ItemActionCommand() {
    this.initialize.apply(this, arguments);
}

Window_ItemActionCommand.prototype = Object.create(Window_Command.prototype);
Window_ItemActionCommand.prototype.constructor = Window_ItemActionCommand;

Window_ItemActionCommand.prototype.initialize = function(x, y) {
    this._windowHeight = Graphics.boxHeight - y;
    Window_Command.prototype.initialize.call(this, x, y);
    this._item = null;
    this.hide();
    this.deactivate();
};

Window_ItemActionCommand.prototype.windowWidth = function() {
    return Graphics.boxWidth / 2;
};

Window_ItemActionCommand.prototype.update = function() {
  Window_Command.prototype.update.call(this);
};

Window_ItemActionCommand.prototype.setItem = function(item) {
    this._item = item;
    this.refresh();
    this.show();
    this.activate();
    this.select(0);
};

Window_ItemActionCommand.prototype.windowHeight = function() {
    return this._windowHeight;
};

Window_ItemActionCommand.prototype.makeCommandList = function() {
    if (!this._item) return;
    this.addUseCommand();
    this.addCustomCommandsA();
    this.addCustomCommandsB();
    this.addCustomCommandsC();
    this.addCustomCommandsD();
    this.addCustomCommandsE();
    this.addCustomCommandsF();
    this.addCancelCommand();
};

Window_ItemActionCommand.prototype.addUseCommand = function() {
    var enabled = this.isEnabled(this._item);
    var fmt = Yanfly.Param.ItemUseCmd;
    text = '\\i[' + this._item.iconIndex + ']';
    if (this._item.textColor !== undefined) {
      text += '\\c[' + this._item.textColor + ']';
    }
    text += this._item.name;
    text = fmt.format(text);
    this.addCommand(text, 'use', enabled);
};

Window_ItemActionCommand.prototype.isEnabled = function(item) {
    if (!item) return false;
    return $gameParty.canUse(item);
};

Window_ItemActionCommand.prototype.addCustomCommandsA = function() {
};

Window_ItemActionCommand.prototype.addCustomCommandsB = function() {
};

Window_ItemActionCommand.prototype.addCustomCommandsC = function() {
};

Window_ItemActionCommand.prototype.addCustomCommandsD = function() {
};

Window_ItemActionCommand.prototype.addCustomCommandsE = function() {
};

Window_ItemActionCommand.prototype.addCustomCommandsF = function() {
};

Window_ItemActionCommand.prototype.addCancelCommand = function() {
    this.addCommand(TextManager.cancel, 'cancel');
};

Window_ItemActionCommand.prototype.drawItem = function(index) {
    var rect = this.itemRectForText(index);
    var align = this.itemTextAlign();
    this.resetTextColor();
    this.changePaintOpacity(this.isCommandEnabled(index));
    this.drawTextEx(this.commandName(index), rect.x, rect.y);
};

//=============================================================================
// Scene_Item
//=============================================================================

Yanfly.Item.Scene_Item_createItemWindow = Scene_Item.prototype.createItemWindow;
Scene_Item.prototype.createItemWindow = function() {
    Yanfly.Item.Scene_Item_createItemWindow.call(this);
    this.createStatusWindow();
    this.createInfoWindow();
    this.createActionWindow();
    this._categoryWindow.setHandler('cancel', this.exitScene.bind(this));
};

Scene_Item.prototype.createStatusWindow = function() {
    var wx = this._categoryWindow.width;
    var wy = this._helpWindow.height;
    var ww = Graphics.boxWidth - wx;
    var wh = this._categoryWindow.height;
    this._statusWindow = new Window_ItemStatus(wx, wy, ww, wh);
    this._itemWindow.setStatusWindow(this._statusWindow);
    this.addWindow(this._statusWindow);
};

Scene_Item.prototype.createInfoWindow = function() {
    var wx = this._itemWindow.width;
    var wy = this._itemWindow.y;
    var ww = Graphics.boxWidth - wx;
    var wh = this._itemWindow.height;
    this._infoWindow = new Window_ItemInfo(wx, wy, ww, wh);
    this._itemWindow.setInfoWindow(this._infoWindow);
    this.addWindow(this._infoWindow);
};

Scene_Item.prototype.createActionWindow = function() {
    var wy = this._itemWindow.y;
    this._itemActionWindow = new Window_ItemActionCommand(0, wy);
    this._itemActionWindow.setHandler('use', this.onActionUse.bind(this));
    this._itemActionWindow.setHandler('cancel', this.onActionCancel.bind(this));
    this.addWindow(this._itemActionWindow);
};

Scene_Item.prototype.isCursorLeft = function() {
    return true;
};

Scene_Item.prototype.onItemOk = function() {
    var item = this.item();
    this._itemActionWindow.setItem(item);
};

Yanfly.Item.Scene_Item_onItemCancel = Scene_Item.prototype.onItemCancel;
Scene_Item.prototype.onItemCancel = function() {
    Yanfly.Item.Scene_Item_onItemCancel.call(this);
    this._statusWindow.setItem(null);
    this._infoWindow.setItem(null);
};

Scene_Item.prototype.onActionUse = function() {
    this._itemActionWindow.hide();
    this._itemActionWindow.deactivate();
    $gameParty.setLastItem(this.item());
    this.determineItem();
};

Scene_Item.prototype.onActionCancel = function() {
    this._itemActionWindow.hide();
    this._itemActionWindow.deactivate();
    this._itemWindow.activate();
};

Yanfly.Item.Scene_Item_applyItem = Scene_Item.prototype.applyItem;
Scene_Item.prototype.applyItem = function() {
    Yanfly.Item.Scene_Item_applyItem.call(this);
    if (DataManager.isIndependent(this.item())) this.onActorCancel();
};

Scene_Item.prototype.exitScene = function() {
    var length = $gameParty.members().length;
    for (var i = 0; i < length; ++i) {
      var member = $gameParty.members()[i];
      if (member) member.refresh();
    }
    this.popScene();
};

//=============================================================================
// Scene_Item Update
//=============================================================================

}; // End Scene_Item

//=============================================================================
// Utilities
//=============================================================================

Yanfly.Util = Yanfly.Util || {};

if (!Yanfly.Util.toGroup) {
   Yanfly.Util.toGroup = function(inVal) {
       return inVal;
   }
};

Yanfly.Util.displayError = function(e, code, message) {
  console.log(message);
  console.log(code || 'NON-EXISTENT');
  console.error(e);
  if (Utils.RPGMAKER_VERSION && Utils.RPGMAKER_VERSION >= "1.6.0") return;
  if (Utils.isNwjs() && Utils.isOptionValid('test')) {
    if (!require('nw.gui').Window.get().isDevToolsOpen()) {
      require('nw.gui').Window.get().showDevTools();
    }
  }
};

DataManager.cleanupIndependentDatabaseItems = function() {
    for (const item of this._independentWeapons || []) {
        if (!item) continue;
        this.clearIndependentItemColorData(item);
        this.clearIndependentItemOnGainEvalData(item);
    }
    for (const item of this._independentArmors || []) {
        if (!item) continue;
        this.clearIndependentItemColorData(item);
        this.clearIndependentItemOnGainEvalData(item);
    }

    // 对武器
    var baseWeaponsLength = this._baseWeaponsLength; // 基底武器数量
    // 清空独立武器数组
    this._independentWeapons = [];
    // 更新 $dataWeapons，只保留基底武器
    $dataWeapons = $dataWeapons.slice(0, baseWeaponsLength);

    // 对护甲
    var baseArmorsLength = this._baseArmorsLength; // 基底护甲数量
    this._independentArmors = [];
    $dataArmors = $dataArmors.slice(0, baseArmorsLength);
};

Game_Party.prototype.cleanupIndependentPartyItems = function() {
    // 先对所有队员执行解除装备操作
    this.members().forEach(function(actor) {
        if (actor) {
            // 遍历角色所有装备槽，并清空装备
            for (var i = 0; i < actor.equips().length; i++) {
                actor.changeEquip(i, null);
            }
        }
    });
    
    // 然后清空存储独立装备的记录
    var baseWeaponsLength = DataManager._baseWeaponsLength;
    for (var key in this._weapons) {
        if (parseInt(key) >= baseWeaponsLength) {
            delete this._weapons[key];
        }
    }
    
    var baseArmorsLength = DataManager._baseArmorsLength;
    for (var key in this._armors) {
        if (parseInt(key) >= baseArmorsLength) {
            delete this._armors[key];
        }
    }
};

/*========================================================================

 ========================================================================*/
/*===========================================================================*
 *  Independent Item Fix -- Reindex + Template-Stub + Fail-Safe (all-in-one) *
 *===========================================================================*/

(function() {
//---------------------------------------------------------------------
// 0. failsafe：任何意外空元素都会被过滤掉
//---------------------------------------------------------------------
const _traits = Game_BattlerBase.prototype.traits;
Game_BattlerBase.prototype.traits = function(code) {
  return _traits.call(this, code).filter(Boolean);  // 跳过 undefined/null
};

//---------------------------------------------------------------------
// 1. 在数据库完全载入后，抓取 300 号模板做深拷贝
//---------------------------------------------------------------------
let weaponTemplate, armorTemplate;

const _isDBLoaded = DataManager.isDatabaseLoaded;
DataManager.isDatabaseLoaded = function() {
  if (!_isDBLoaded.call(this)) return false;
  if (weaponTemplate === undefined) {
    weaponTemplate = clone($dataWeapons[290]);
    armorTemplate  = clone($dataArmors[290]);
  }
  return true;
};

// 深拷贝工具

function clone(obj) {
  return obj ? JSON.parse(JSON.stringify(obj)) : undefined;
}

//---------------------------------------------------------------------
// 2. 重写 loadIndependentItems：迁移 → 去重 → 填充占位壳
//---------------------------------------------------------------------
const _loadIndItems = DataManager.loadIndependentItems;
DataManager.loadIndependentItems = function() {

  _loadIndItems.call(this);                 // 先跑原始流程

  // --- 2-1 旧独立物品回到正确 id ---
  const reIndex = (db, list) => {
    if (!Array.isArray(list)) return;
    list.forEach(item => {
      if (!item) return;
      while (db.length <= item.id) db.push(null);
      db[item.id] = item;
    });
  };
  reIndex($dataItems,   this._independentItems);
  reIndex($dataWeapons, this._independentWeapons);
  reIndex($dataArmors,  this._independentArmors);

  // --- 2-2 清掉错位副本 ---
  const sanitize = db => {
    for (let i = 0; i < db.length; i++) {
      const it = db[i];
      if (it && it.id !== i) db[i] = null;
    }
  };
  sanitize($dataWeapons);
  sanitize($dataArmors);

  // --- 2-3 null → 占位壳（取模板深拷贝；若无模板则兜底） ---
  fillStubs($dataWeapons, makeWeaponStub);
  fillStubs($dataArmors,  makeArmorStub);
};

//---------------------------------------------------------------------
// 3. 生成占位壳
//---------------------------------------------------------------------
function fillStubs(db, builder) {
  for (let i = 0; i < db.length; i++) {
    if (db[i] == null) db[i] = builder(i);
  }
}

function makeWeaponStub(id) {
  let w = clone(weaponTemplate);
  if (!w) {                                // 模板不存在 → 兜底
    w = {
      id, animationId:0, description:'', etypeId:1, traits:[],
      iconIndex:0, name:'', note:'', params:[0,0,0,0,0,0,0,0],
      price:0, wtypeId:0, meta:{}
    };
  }
  w.id = id;               // 保证下标＝id
  w.name = '';
  w.description = '';
  w.meta = {};
  w._independentTemplateStub = true;
  return w;
}

function makeArmorStub(id) {
  let a = clone(armorTemplate);
  if (!a) {
    a = {
      id, description:'', etypeId:2, atypeId:0, traits:[],
      iconIndex:0, name:'error item', note:'', params:[0,0,0,0,0,0,0,0],
      price:0, meta:{}
    };
  }
  a.id = id;
  a.name = '';
  a.description = '';
  a.meta = {};
  a._independentTemplateStub = true;
  return a;
}

})();  

/*===========================================================================*
 * Independent Item/Equipment Template Fingerprint Compatibility
 *===========================================================================*/

(() => {
    'use strict';

    const TEMPLATE_FINGERPRINT_SCHEMA = 1;
    const INDEPENDENT_EQUIP_PATCH_SCHEMA = 1;
    const INDEPENDENT_EQUIP_PATCH_FIELD = '_independentEquipPatches';
    const templateFingerprintCache = new WeakMap();
    const templateFieldCache = new Map();
    const NAME_COMPONENT_FIELDS = new Set([
        'baseItemName',
        'namePrefix',
        'nameSuffix',
        'priorityName',
        'boostCount'
    ]);
    const PROTECTED_PATCH_PROPERTIES = new Set([
        'id',
        'baseItemId',
        'baseItemName',
        'baseItemPrice',
        'baseItemIconIndex',
        'etypeId',
        'wtypeId',
        'atypeId',
        'itypeId',
        'animationId',
        'params',
        'rateParams',
        'traits',
        'meta',
        'note',
        'durability',
        'durMax',
        'itemRank',
        '_templateFingerprint',
        '_rubedoFingerprint',
        INDEPENDENT_EQUIP_PATCH_FIELD
    ]);
    const UNSAFE_PATCH_KEYS = new Set([
        '__proto__',
        'prototype',
        'constructor'
    ]);
    const PRESERVED_INSTANCE_FIELDS = new Set([
        'id',
        'baseItemId',
        'name',
        'description',
        'iconIndex',
        'note',
        'etypeId',
        'wtypeId',
        'atypeId',
        'animationId',
        'baseItemName',
        'baseItemPrice',
        'baseItemIconIndex',
        'namePrefix',
        'nameSuffix',
        'priorityName',
        'boostCount',
        'itemRank',
        'onCreationEval',
        'durability',
        'durMax',
        'rateParams',
        '_templateFingerprint',
        '_rubedoFingerprint',
        INDEPENDENT_EQUIP_PATCH_FIELD
    ]);

    const isItemData = item => Boolean(item) && item.itypeId !== undefined;
    const isWeaponData = item => Boolean(item) && item.wtypeId !== undefined;
    const isArmorData = item => Boolean(item) && item.atypeId !== undefined;

    const templateKind = item => {
        if (isItemData(item)) return 'item';
        if (isWeaponData(item)) return 'weapon';
        if (isArmorData(item)) return 'armor';
        return '';
    };

    const equipKind = item => {
        if (isWeaponData(item)) return 'weapon';
        if (isArmorData(item)) return 'armor';
        return '';
    };

    const normalizeNote = note => String(note || '').replace(/\r\n?/g, '\n');

    const cloneValue = value => {
        if (value === undefined || value === null) return value;
        if (typeof value !== 'object') return value;
        return JSON.parse(JSON.stringify(value));
    };

    const normalizedParams = params => {
        const result = [];
        for (let index = 0; index < 8; index++) {
            const value = Array.isArray(params) ? Number(params[index]) : 0;
            result.push(Number.isFinite(value) ? value : 0);
        }
        return result;
    };

    const normalizedTraits = traits => {
        if (!Array.isArray(traits)) return [];
        return traits.map(trait => {
            if (!trait) return null;
            const code = Number(trait.code);
            const dataId = Number(trait.dataId);
            const value = Number(trait.value);
            return [
                Number.isFinite(code) ? code : 0,
                Number.isFinite(dataId) ? dataId : 0,
                Number.isFinite(value) ? value : 0
            ];
        });
    };

    const templateFingerprintSource = baseItem => JSON.stringify({
        kind: templateKind(baseItem),
        baseItemId: Number(baseItem.id) || 0,
        price: Number(baseItem.price) || 0,
        params: normalizedParams(baseItem.params),
        traits: normalizedTraits(baseItem.traits),
        note: normalizeNote(baseItem.note)
    });

    const toHex32 = value => (
        `00000000${(value >>> 0).toString(16)}`.slice(-8)
    );

    const fnv1a32 = (text, seed) => {
        let hash = seed >>> 0;
        for (let index = 0; index < text.length; index++) {
            const code = text.charCodeAt(index);
            hash ^= code & 0xff;
            hash = Math.imul(hash, 0x01000193);
            hash ^= code >>> 8;
            hash = Math.imul(hash, 0x01000193);
        }
        return toHex32(hash);
    };

    DataManager.makeIndependentEquipTemplateFingerprint = baseItem => {
        if (!templateKind(baseItem)) return null;
        if (templateFingerprintCache.has(baseItem)) {
            return templateFingerprintCache.get(baseItem);
        }

        const source = templateFingerprintSource(baseItem);
        const hash =
            fnv1a32(source, 0x811c9dc5) +
            fnv1a32(source, 0x9747b28c);
        const fingerprint = `${TEMPLATE_FINGERPRINT_SCHEMA}:${hash}`;
        templateFingerprintCache.set(baseItem, fingerprint);
        return fingerprint;
    };

    // 新名称覆盖物品、武器和护甲；保留旧 API 名称以兼容现有调用。
    DataManager.makeIndependentTemplateFingerprint = baseItem => (
        DataManager.makeIndependentEquipTemplateFingerprint(baseItem)
    );

    const databaseForKind = kind => {
        if (kind === 'item') return $dataItems;
        if (kind === 'weapon') return $dataWeapons;
        return $dataArmors;
    };

    const independentListForKind = kind => {
        if (kind === 'item') return DataManager._independentItems;
        if (kind === 'weapon') return DataManager._independentWeapons;
        return DataManager._independentArmors;
    };

    const baseLengthForKind = kind => {
        if (kind === 'item') return DataManager._baseItemsLength;
        if (kind === 'weapon') return DataManager._baseWeaponsLength;
        return DataManager._baseArmorsLength;
    };

    const validBaseTemplate = baseItem => (
        Boolean(baseItem) &&
        !baseItem.baseItemId &&
        !baseItem._independentTemplateStub
    );

    const currentBaseItem = (item, kind) => {
        const baseItemId = Number(item && item.baseItemId);
        const baseLength = Number(baseLengthForKind(kind)) || 0;
        if (
            !Number.isInteger(baseItemId) ||
            baseItemId <= 0 ||
            baseItemId >= baseLength
        ) {
            return null;
        }

        const database = databaseForKind(kind);
        const baseItem = database && database[baseItemId];
        return validBaseTemplate(baseItem) ? baseItem : null;
    };

    const templateOwnedFields = kind => {
        if (templateFieldCache.has(kind)) {
            return templateFieldCache.get(kind);
        }

        const fields = new Set();
        const database = databaseForKind(kind) || [];
        const baseLength = Number(baseLengthForKind(kind)) || 0;
        for (let index = 1; index < baseLength; index++) {
            const baseItem = database[index];
            if (!validBaseTemplate(baseItem)) continue;
            for (const key of Object.keys(baseItem)) {
                fields.add(key);
            }
        }

        templateFieldCache.set(kind, fields);
        return fields;
    };

    const syncTemplateOwnedFields = (item, baseItem, kind) => {
        for (const key of templateOwnedFields(kind)) {
            if (PRESERVED_INSTANCE_FIELDS.has(key)) continue;
            if (Object.prototype.hasOwnProperty.call(baseItem, key)) {
                item[key] = cloneValue(baseItem[key]);
            } else {
                delete item[key];
            }
        }

        item.price = Number(baseItem.price) || 0;
        if (kind !== 'item') {
            item.params = cloneValue(baseItem.params) ||
                [0, 0, 0, 0, 0, 0, 0, 0];
            item.traits = cloneValue(baseItem.traits) || [];
        }
        item.meta = cloneValue(baseItem.meta) || {};
        item.baseItemPrice = item.price;
        item.note = '';
    };

    const rubedoApplications = item => {
        const fingerprint = item && item._rubedoFingerprint;
        if (
            !fingerprint ||
            fingerprint.schema !== 1 ||
            !Array.isArray(fingerprint.applications)
        ) {
            return [];
        }
        return fingerprint.applications;
    };

    const rebuildRateParams = (item, baseItem) => {
        const applications = rubedoApplications(item);
        if (baseItem.rateParams !== undefined) {
            item.rateParams = cloneValue(baseItem.rateParams);
        } else if (applications.length > 0) {
            item.rateParams = [1, 1, 1, 1, 1, 1, 1, 1];
        } else {
            delete item.rateParams;
            return;
        }

        for (const application of applications) {
            const boosts = application && application.rateParamBoosts;
            if (!boosts || typeof boosts !== 'object') continue;

            for (const key of Object.keys(boosts)) {
                const dataId = Number(key);
                const boost = Number(boosts[key]);
                if (
                    !Number.isInteger(dataId) ||
                    dataId < 0 ||
                    !Number.isFinite(boost)
                ) {
                    continue;
                }

                let current = Number(item.rateParams[dataId]);
                if (!Number.isFinite(current)) current = 1;
                item.rateParams[dataId] = current + boost / 100;
            }
        }
    };

    const rebuildDurability = (
        item,
        baseItem,
        oldDurability,
        oldDurMax
    ) => {
        const baseDurMax = Number(baseItem.durMax);
        if (!Number.isFinite(baseDurMax)) return;

        let newDurMax = baseDurMax;
        for (const application of rubedoApplications(item)) {
            const boost = Number(application && application.durabilityBoost);
            if (!Number.isFinite(boost)) continue;
            newDurMax = Math.floor(newDurMax * (1 + boost / 100));
        }
        newDurMax += independentEquipDurabilityBonus(item);

        item.durMax = newDurMax;

        if (!Number.isFinite(oldDurability)) {
            const baseDurability = Number(baseItem.durability);
            if (Number.isFinite(baseDurability)) {
                item.durability = Math.min(baseDurability, newDurMax);
            }
            return;
        }

        if (oldDurability < 0) {
            item.durability = oldDurability;
            return;
        }

        if (Number.isFinite(oldDurMax) && oldDurMax > 0 && newDurMax >= 0) {
            const ratio = Math.max(
                0,
                Math.min(1, oldDurability / oldDurMax)
            );
            item.durability = Math.floor(newDurMax * ratio);
        } else if (newDurMax >= 0) {
            item.durability = Math.min(oldDurability, newDurMax);
        } else {
            item.durability = oldDurability;
        }
    };

    const evalText = (item, key) => {
        const value = item && item[key];
        return value == null ? '' : String(value);
    };

    const leaderEquipSlots = item => {
        if (
            typeof $gameParty === 'undefined' ||
            !$gameParty ||
            typeof $gameParty.leader !== 'function'
        ) {
            return [];
        }

        const actor = $gameParty.leader();
        if (!actor || typeof actor.equips !== 'function') return [];

        const slots = [];
        const equips = actor.equips();
        for (let slotId = 0; slotId < equips.length; slotId++) {
            if (equips[slotId] === item) {
                slots.push({ actor, slotId });
            }
        }
        return slots;
    };

    const restoreObject = (target, backup) => {
        for (const key of Object.keys(target)) {
            delete target[key];
        }
        for (const key of Object.keys(backup)) {
            target[key] = cloneValue(backup[key]);
        }
    };

    const restoreEquippedSlots = (slots, item) => {
        for (const { actor, slotId } of slots) {
            if (actor.equips()[slotId] !== item) {
                actor.changeEquip(slotId, item);
            }
        }
    };

    const patchError = message => (
        new Error(`[YEP_ItemCore] Independent equipment patch: ${message}`)
    );

    const clonePatchValue = (value, label) => {
        let json;
        try {
            json = JSON.stringify(value, (key, nestedValue) => {
                const type = typeof nestedValue;
                if (
                    type === 'undefined' ||
                    type === 'function' ||
                    type === 'symbol'
                ) {
                    throw patchError(
                        `${label} contains a non-serializable value`
                    );
                }
                if (
                    type === 'number' &&
                    !Number.isFinite(nestedValue)
                ) {
                    throw patchError(
                        `${label} contains a non-finite number`
                    );
                }
                return nestedValue;
            });
        } catch (error) {
            if (
                error &&
                String(error.message).indexOf('[YEP_ItemCore]') === 0
            ) {
                throw error;
            }
            throw patchError(`${label} must be JSON-serializable`);
        }

        if (json === undefined) {
            throw patchError(`${label} must be JSON-serializable`);
        }
        return JSON.parse(json);
    };

    const normalizePatchKey = (value, label) => {
        const key = String(value == null ? '' : value).trim();
        if (!key) throw patchError(`${label} cannot be empty`);
        if (UNSAFE_PATCH_KEYS.has(key)) {
            throw patchError(`${label} "${key}" is not allowed`);
        }
        return key;
    };

    const normalizeParamOperation = (operation, type) => {
        const paramId = Number(operation.paramId);
        const value = Number(operation.value);
        if (!Number.isInteger(paramId) || paramId < 0 || paramId > 7) {
            throw patchError(`${type}.paramId must be an integer from 0 to 7`);
        }
        if (!Number.isFinite(value)) {
            throw patchError(`${type}.value must be a finite number`);
        }
        return { type, paramId, value };
    };

    const normalizeNumericOperation = (operation, type) => {
        const value = Number(operation.value);
        if (!Number.isFinite(value)) {
            throw patchError(`${type}.value must be a finite number`);
        }
        return { type, value };
    };

    const normalizeArmorTypeOperation = operation => {
        const value = Number(operation.value);
        if (!Number.isInteger(value) || value <= 0) {
            throw patchError(
                'setArmorType.value must be a positive integer'
            );
        }
        return {
            type: 'setArmorType',
            value
        };
    };

    const normalizeTrait = (trait, valueRequired) => {
        if (!trait || typeof trait !== 'object' || Array.isArray(trait)) {
            throw patchError('trait must be an object');
        }

        const code = Number(trait.code);
        const dataId = Number(trait.dataId);
        if (!Number.isInteger(code) || code < 0) {
            throw patchError('trait.code must be a non-negative integer');
        }
        if (!Number.isInteger(dataId) || dataId < 0) {
            throw patchError('trait.dataId must be a non-negative integer');
        }

        const result = { code, dataId };
        if (valueRequired || trait.value !== undefined) {
            const value = Number(trait.value);
            if (!Number.isFinite(value)) {
                throw patchError('trait.value must be a finite number');
            }
            result.value = value;
        }
        return result;
    };

    const normalizePatchOperation = operation => {
        if (
            !operation ||
            typeof operation !== 'object' ||
            Array.isArray(operation)
        ) {
            throw patchError('each operation must be an object');
        }

        const type = String(operation.type || '');
        switch (type) {
            case 'setProperty': {
                const key = normalizePatchKey(
                    operation.key,
                    'setProperty.key'
                );
                if (PROTECTED_PATCH_PROPERTIES.has(key)) {
                    throw patchError(
                        `setProperty cannot modify protected field "${key}"`
                    );
                }
                return {
                    type,
                    key,
                    value: clonePatchValue(
                        operation.value,
                        `setProperty "${key}"`
                    )
                };
            }
            case 'setParam':
            case 'addParam':
            case 'setRateParam':
            case 'addRateParam':
                return normalizeParamOperation(operation, type);
            case 'addDurability':
                return normalizeNumericOperation(operation, type);
            case 'setArmorType':
                return normalizeArmorTypeOperation(operation);
            case 'addTrait':
                return {
                    type,
                    trait: normalizeTrait(operation.trait, true)
                };
            case 'removeTrait':
                return {
                    type,
                    trait: normalizeTrait(operation.trait, false)
                };
            case 'setMeta': {
                const key = normalizePatchKey(operation.key, 'setMeta.key');
                return {
                    type,
                    key,
                    value: clonePatchValue(
                        operation.value,
                        `setMeta "${key}"`
                    )
                };
            }
            case 'deleteMeta':
                return {
                    type,
                    key: normalizePatchKey(
                        operation.key,
                        'deleteMeta.key'
                    )
                };
            case 'setColor': {
                if (typeof operation.value !== 'string') {
                    throw patchError('setColor.value must be a string');
                }
                return { type, value: operation.value };
            }
            default:
                throw patchError(`unknown operation type "${type}"`);
        }
    };

    const normalizePatchDefinition = patch => {
        if (!patch || typeof patch !== 'object' || Array.isArray(patch)) {
            throw patchError('patch definition must be an object');
        }

        const id = normalizePatchKey(patch.id, 'patch.id');
        if (!Array.isArray(patch.operations) || patch.operations.length === 0) {
            throw patchError(`patch "${id}" must contain operations`);
        }

        return {
            id,
            operations: patch.operations.map(normalizePatchOperation)
        };
    };

    const storedIndependentEquipPatches = item => {
        const state = item && item[INDEPENDENT_EQUIP_PATCH_FIELD];
        if (state == null) return [];
        if (
            !state ||
            state.schema !== INDEPENDENT_EQUIP_PATCH_SCHEMA ||
            !Array.isArray(state.patches)
        ) {
            throw patchError('stored patch data has an unsupported format');
        }

        const patches = state.patches.map(normalizePatchDefinition);
        const ids = new Set();
        for (const patch of patches) {
            if (ids.has(patch.id)) {
                throw patchError(`stored patch id "${patch.id}" is duplicated`);
            }
            ids.add(patch.id);
        }
        return patches;
    };

    const independentEquipDurabilityBonus = item => {
        let bonus = 0;
        for (const patch of storedIndependentEquipPatches(item)) {
            for (const operation of patch.operations) {
                if (operation.type === 'addDurability') {
                    bonus += operation.value;
                }
            }
        }
        return bonus;
    };

    const traitMatches = (trait, expected) => {
        if (!trait) return false;
        if (
            Number(trait.code) !== expected.code ||
            Number(trait.dataId) !== expected.dataId
        ) {
            return false;
        }
        return (
            expected.value === undefined ||
            Number(trait.value) === expected.value
        );
    };

    const ensureParamArray = (item, key, defaultValue) => {
        if (!Array.isArray(item[key])) item[key] = [];
        while (item[key].length < 8) item[key].push(defaultValue);
        return item[key];
    };

    const colorTableProperty = kind => (
        kind === 'weapon'
            ? '_drill_ITC_colorCode_Weapon'
            : '_drill_ITC_colorCode_Armor'
    );

    const hasIndependentEquipColorRegistration = (item, kind) => {
        if (
            typeof $gameSystem === 'undefined' ||
            !$gameSystem
        ) {
            return false;
        }

        const table = $gameSystem[colorTableProperty(kind)];
        if (!table || typeof table !== 'object') return false;
        const colorCode = table[item.id];
        return colorCode !== undefined && colorCode !== null;
    };

    const setIndependentEquipColor = (item, kind, colorCode) => {
        if (
            typeof $gameSystem === 'undefined' ||
            !$gameSystem
        ) {
            throw patchError('setColor requires $gameSystem');
        }

        const property = colorTableProperty(kind);
        if (!Array.isArray($gameSystem[property])) {
            $gameSystem[property] = [];
        }
        $gameSystem[property][item.id] = colorCode;
    };

    const captureIndependentEquipColor = (item, kind) => {
        if (
            typeof $gameSystem === 'undefined' ||
            !$gameSystem
        ) {
            return { available: false };
        }

        const property = colorTableProperty(kind);
        const table = $gameSystem[property];
        const hadTable = Array.isArray(table);
        const hadEntry = hadTable &&
            Object.prototype.hasOwnProperty.call(table, item.id);
        return {
            available: true,
            property,
            hadTable,
            hadEntry,
            value: hadEntry ? table[item.id] : undefined
        };
    };

    const restoreIndependentEquipColor = (item, backup) => {
        if (!backup.available) return;
        if (!backup.hadTable) {
            delete $gameSystem[backup.property];
            return;
        }

        if (!Array.isArray($gameSystem[backup.property])) {
            $gameSystem[backup.property] = [];
        }
        if (backup.hadEntry) {
            $gameSystem[backup.property][item.id] = backup.value;
        } else {
            delete $gameSystem[backup.property][item.id];
        }
    };

    const createPatchEffects = () => ({
        refreshName: false
    });

    const applyIndependentEquipPatchOperation = (
        item,
        kind,
        operation,
        effects,
        replaying
    ) => {
        switch (operation.type) {
            case 'setProperty':
                item[operation.key] = cloneValue(operation.value);
                if (NAME_COMPONENT_FIELDS.has(operation.key)) {
                    effects.refreshName = true;
                }
                break;
            case 'setParam': {
                const params = ensureParamArray(item, 'params', 0);
                params[operation.paramId] = operation.value;
                break;
            }
            case 'addParam': {
                const params = ensureParamArray(item, 'params', 0);
                const current = Number(params[operation.paramId]);
                params[operation.paramId] =
                    (Number.isFinite(current) ? current : 0) +
                    operation.value;
                break;
            }
            case 'setRateParam': {
                const params = ensureParamArray(item, 'rateParams', 1);
                params[operation.paramId] = operation.value;
                break;
            }
            case 'addRateParam': {
                const params = ensureParamArray(item, 'rateParams', 1);
                const current = Number(params[operation.paramId]);
                params[operation.paramId] =
                    (Number.isFinite(current) ? current : 1) +
                    operation.value;
                break;
            }
            case 'addDurability': {
                if (replaying) break;
                const durability = Number(item.durability);
                const durMax = Number(item.durMax);
                if (
                    !Number.isFinite(durability) ||
                    !Number.isFinite(durMax)
                ) {
                    throw patchError(
                        'addDurability requires numeric durability and durMax'
                    );
                }
                item.durability = durability + operation.value;
                item.durMax = durMax + operation.value;
                break;
            }
            case 'setArmorType':
                if (kind !== 'armor') {
                    throw patchError(
                        'setArmorType can only modify an independent armor'
                    );
                }
                item.atypeId = operation.value;
                break;
            case 'addTrait':
                if (!Array.isArray(item.traits)) item.traits = [];
                if (!item.traits.some(trait => (
                    traitMatches(trait, operation.trait)
                ))) {
                    item.traits.push(cloneValue(operation.trait));
                }
                break;
            case 'removeTrait':
                if (!Array.isArray(item.traits)) item.traits = [];
                item.traits = item.traits.filter(trait => (
                    !traitMatches(trait, operation.trait)
                ));
                break;
            case 'setMeta':
                if (
                    !item.meta ||
                    typeof item.meta !== 'object' ||
                    Array.isArray(item.meta)
                ) {
                    item.meta = {};
                }
                item.meta[operation.key] = cloneValue(operation.value);
                break;
            case 'deleteMeta':
                if (
                    item.meta &&
                    typeof item.meta === 'object' &&
                    !Array.isArray(item.meta)
                ) {
                    delete item.meta[operation.key];
                }
                break;
            case 'setColor':
                setIndependentEquipColor(item, kind, operation.value);
                break;
        }
    };

    const finalizeIndependentEquipPatchEffects = (item, effects) => {
        if (
            effects.refreshName &&
            typeof ItemManager.updateItemName === 'function'
        ) {
            ItemManager.updateItemName(item);
        }
        item.itemRank = ItemManager.getItemRankByColor(item);
    };

    const applyIndependentEquipPatchOperations = (
        item,
        kind,
        operations
    ) => {
        const effects = createPatchEffects();
        for (const operation of operations) {
            applyIndependentEquipPatchOperation(
                item,
                kind,
                operation,
                effects,
                false
            );
        }
        finalizeIndependentEquipPatchEffects(item, effects);
    };

    const replayIndependentEquipPatches = (item, kind) => {
        const patches = storedIndependentEquipPatches(item);
        const effects = createPatchEffects();
        for (const patch of patches) {
            for (const operation of patch.operations) {
                applyIndependentEquipPatchOperation(
                    item,
                    kind,
                    operation,
                    effects,
                    true
                );
            }
        }
        finalizeIndependentEquipPatchEffects(item, effects);
        return patches.length;
    };

    const patchChangesEquipEval = patch => (
        patch.operations.some(operation => (
            operation.type === 'setProperty' &&
            (
                operation.key === 'customOnEquipEval' ||
                operation.key === 'customOnRemoveEquipEval'
            )
        ))
    );

    const refreshPatchActors = slots => {
        const refreshedActors = new Set();
        for (const { actor } of slots) {
            if (
                refreshedActors.has(actor) ||
                typeof actor.refresh !== 'function'
            ) {
                continue;
            }
            actor.refresh();
            refreshedActors.add(actor);
        }
    };

    DataManager.hasIndependentEquipPatch = (item, patchId) => {
        const id = normalizePatchKey(patchId, 'patch.id');
        return storedIndependentEquipPatches(item).some(patch => (
            patch.id === id
        ));
    };

    DataManager.applyIndependentEquipPatch = (item, patchDefinition) => {
        const kind = equipKind(item);
        if (!kind || !item || !item.baseItemId) {
            throw patchError('target must be an independent weapon or armor');
        }

        const patch = normalizePatchDefinition(patchDefinition);
        const storedPatches = storedIndependentEquipPatches(item);
        const existingPatch = storedPatches.find(candidate => (
            candidate.id === patch.id
        ));
        if (existingPatch) {
            if (
                JSON.stringify(existingPatch.operations) !==
                JSON.stringify(patch.operations)
            ) {
                throw patchError(
                    `patch id "${patch.id}" already uses another definition`
                );
            }
            return false;
        }

        const backup = cloneValue(item);
        const colorBackup = captureIndependentEquipColor(item, kind);
        const slots = leaderEquipSlots(item);
        const needsEquipCycle =
            slots.length > 0 &&
            patchChangesEquipEval(patch);

        try {
            if (needsEquipCycle) {
                for (const { actor, slotId } of slots) {
                    actor.changeEquip(slotId, null);
                }
            }

            applyIndependentEquipPatchOperations(
                item,
                kind,
                patch.operations
            );
            item[INDEPENDENT_EQUIP_PATCH_FIELD] = {
                schema: INDEPENDENT_EQUIP_PATCH_SCHEMA,
                patches: storedPatches.concat([patch])
            };

            if (needsEquipCycle) {
                restoreEquippedSlots(slots, item);
                for (const { actor, slotId } of slots) {
                    if (actor.equips()[slotId] !== item) {
                        throw patchError(
                            `failed to restore equipment to slot ${slotId}`
                        );
                    }
                }
            }

            refreshPatchActors(slots);
            return true;
        } catch (error) {
            restoreObject(item, backup);
            restoreIndependentEquipColor(item, colorBackup);
            try {
                restoreEquippedSlots(slots, item);
            } catch (restoreError) {
                console.error(
                    '[YEP_ItemCore] Failed to restore equipment after ' +
                    'patch error:',
                    restoreError
                );
            }
            throw error;
        }
    };

    const updateRubedoColor = (item, kind) => {
        if (
            kind !== 'weapon' ||
            typeof $gameSystem === 'undefined' ||
            !$gameSystem
        ) {
            return;
        }

        const applications = rubedoApplications(item);
        if (applications.length === 0) return;

        const lastApplication = applications[applications.length - 1];
        const colorCode = lastApplication && lastApplication.colorCode;
        if (colorCode == null) return;

        if (!$gameSystem._drill_ITC_colorCode_Weapon) {
            $gameSystem._drill_ITC_colorCode_Weapon = [];
        }
        $gameSystem._drill_ITC_colorCode_Weapon[item.id] = String(colorCode);
    };

    const captureLegacyDurability = item => ({
        hasDurability: Object.prototype.hasOwnProperty.call(
            item,
            'durability'
        ),
        durability: cloneValue(item.durability),
        hasDurMax: Object.prototype.hasOwnProperty.call(item, 'durMax'),
        durMax: cloneValue(item.durMax)
    });

    const restoreLegacyDurability = (item, state) => {
        if (state.hasDurability) {
            item.durability = cloneValue(state.durability);
        } else {
            delete item.durability;
        }

        if (state.hasDurMax) {
            item.durMax = cloneValue(state.durMax);
        } else {
            delete item.durMax;
        }
    };

    const resetLegacyRateParams = (item, baseItem) => {
        if (baseItem.rateParams !== undefined) {
            item.rateParams = cloneValue(baseItem.rateParams);
        } else {
            delete item.rateParams;
        }
    };

    // 普通独立物品没有装备槽、耐久度或装备补丁。这里只同步模板拥有的
    // 字段并保留实例专属数据（例如封术卷轴的 sealingItems）。
    const migrateFingerprintedRegularItem = (
        item,
        baseItem,
        newFingerprint
    ) => {
        const backup = cloneValue(item);

        try {
            syncTemplateOwnedFields(item, baseItem, 'item');
            item.itemRank = ItemManager.getItemRankByColor(item);
            item._templateFingerprint = newFingerprint;
            return true;
        } catch (error) {
            restoreObject(item, backup);
            throw error;
        }
    };

    const migrateUnfingerprintedItem = (
        item,
        baseItem,
        kind,
        newFingerprint
    ) => {
        const backup = cloneValue(item);
        const colorBackup = captureIndependentEquipColor(item, kind);
        const slots = leaderEquipSlots(item);
        const durabilityState = captureLegacyDurability(item);
        const oldOnEquip = evalText(item, 'customOnEquipEval');
        const oldOnRemove = evalText(item, 'customOnRemoveEquipEval');
        const newOnEquip = evalText(baseItem, 'customOnEquipEval');
        const newOnRemove = evalText(baseItem, 'customOnRemoveEquipEval');
        const hasCustomEquipEffect =
            oldOnEquip !== '' ||
            oldOnRemove !== '' ||
            newOnEquip !== '' ||
            newOnRemove !== '';
        const needsEquipCycle = slots.length > 0 && hasCustomEquipEffect;

        try {
            if (needsEquipCycle) {
                for (const { actor, slotId } of slots) {
                    actor.changeEquip(slotId, null);
                }
            }

            syncTemplateOwnedFields(item, baseItem, kind);
            resetLegacyRateParams(item, baseItem);
            delete item._rubedoFingerprint;
            delete item[INDEPENDENT_EQUIP_PATCH_FIELD];
            item.itemRank = ItemManager.getItemRankByColor(item);
            restoreLegacyDurability(item, durabilityState);

            if (needsEquipCycle) {
                restoreEquippedSlots(slots, item);
                for (const { actor, slotId } of slots) {
                    if (actor.equips()[slotId] !== item) {
                        throw new Error(
                            `Failed to restore legacy independent ` +
                            `equipment to slot ${slotId}`
                        );
                    }
                }
            }

            restoreLegacyDurability(item, durabilityState);
            item._templateFingerprint = newFingerprint;
            refreshPatchActors(slots);
            return true;
        } catch (error) {
            restoreObject(item, backup);
            restoreIndependentEquipColor(item, colorBackup);
            try {
                restoreEquippedSlots(slots, item);
            } catch (restoreError) {
                console.error(
                    '[YEP_ItemCore] Failed to restore equipment after ' +
                    'legacy migration error:',
                    restoreError
                );
            }
            throw error;
        }
    };

    const migrateFingerprintedItem = (
        item,
        baseItem,
        kind,
        newFingerprint
    ) => {
        const backup = cloneValue(item);
        const colorBackup = captureIndependentEquipColor(item, kind);
        const slots = leaderEquipSlots(item);
        const oldOnEquip = evalText(item, 'customOnEquipEval');
        const oldOnRemove = evalText(item, 'customOnRemoveEquipEval');
        const newOnEquip = evalText(baseItem, 'customOnEquipEval');
        const newOnRemove = evalText(baseItem, 'customOnRemoveEquipEval');
        const hasCustomEquipEffect =
            oldOnEquip !== '' ||
            oldOnRemove !== '' ||
            newOnEquip !== '' ||
            newOnRemove !== '';
        const needsEquipCycle = slots.length > 0 && hasCustomEquipEffect;
        const oldDurability = Number(item.durability);
        const oldDurMax = Number(item.durMax);

        try {
            if (needsEquipCycle) {
                for (const { actor, slotId } of slots) {
                    actor.changeEquip(slotId, null);
                }
            }

            syncTemplateOwnedFields(item, baseItem, kind);
            rebuildRateParams(item, baseItem);
            rebuildDurability(item, baseItem, oldDurability, oldDurMax);
            updateRubedoColor(item, kind);
            replayIndependentEquipPatches(item, kind);

            if (needsEquipCycle) {
                restoreEquippedSlots(slots, item);
                for (const { actor, slotId } of slots) {
                    if (actor.equips()[slotId] !== item) {
                        throw new Error(
                            `Failed to restore independent equipment ` +
                            `to slot ${slotId}`
                        );
                    }
                }
            }

            item._templateFingerprint = newFingerprint;
            refreshPatchActors(slots);
            return true;
        } catch (error) {
            restoreObject(item, backup);
            restoreIndependentEquipColor(item, colorBackup);
            try {
                restoreEquippedSlots(slots, item);
            } catch (restoreError) {
                console.error(
                    '[YEP_ItemCore] Failed to restore equipment after ' +
                    'migration error:',
                    restoreError
                );
            }
            throw error;
        }
    };

    // Public entry point for Common Event 2. Fingerprinted objects use the
    // replay route; legacy objects without a fingerprint are either adopted
    // from the current template or conservatively skipped when color-marked.
    DataManager.migrateFingerprintedIndependentEquips = () => {
        const result = {
            total: 0,
            checked: 0,
            migrated: 0,
            unchanged: 0,
            withoutFingerprint: 0,
            legacyChecked: 0,
            legacyMigrated: 0,
            skippedWithoutFingerprint: 0,
            skippedLegacyItems: 0,
            skippedRegisteredColor: 0,
            skippedInvalid: 0,
            missingBase: 0,
            failed: 0,
            errors: []
        };

        for (const kind of ['item', 'weapon', 'armor']) {
            const list = independentListForKind(kind);
            if (!Array.isArray(list)) continue;

            for (const item of list) {
                if (!item) continue;
                result.total++;

                if (templateKind(item) !== kind || !item.baseItemId) {
                    result.skippedInvalid++;
                    continue;
                }

                if (typeof item._templateFingerprint !== 'string') {
                    result.withoutFingerprint++;

                    // 旧版本没有为普通独立物品生成指纹。这里不做全量猜测，
                    // 由限时公共事件按 baseItemId 定向修复并补录指纹。
                    if (kind === 'item') {
                        result.skippedWithoutFingerprint++;
                        result.skippedLegacyItems++;
                        continue;
                    }

                    if (
                        hasIndependentEquipColorRegistration(item, kind)
                    ) {
                        result.skippedWithoutFingerprint++;
                        result.skippedRegisteredColor++;
                        continue;
                    }

                    result.legacyChecked++;
                    const legacyBaseItem = currentBaseItem(item, kind);
                    if (!legacyBaseItem) {
                        result.skippedWithoutFingerprint++;
                        result.missingBase++;
                        continue;
                    }

                    const legacyFingerprint =
                        DataManager
                            .makeIndependentEquipTemplateFingerprint(
                                legacyBaseItem
                            );
                    try {
                        migrateUnfingerprintedItem(
                            item,
                            legacyBaseItem,
                            kind,
                            legacyFingerprint
                        );
                        result.legacyMigrated++;
                    } catch (error) {
                        result.skippedWithoutFingerprint++;
                        result.failed++;
                        result.errors.push({
                            phase: 'legacy',
                            kind,
                            id: item.id,
                            baseItemId: item.baseItemId,
                            message: error && error.message
                                ? String(error.message)
                                : String(error)
                        });
                        console.error(
                            '[YEP_ItemCore] Legacy independent equipment ' +
                            'migration failed:',
                            kind,
                            item.id,
                            error
                        );
                    }
                    continue;
                }

                result.checked++;
                const baseItem = currentBaseItem(item, kind);
                if (!baseItem) {
                    result.missingBase++;
                    continue;
                }

                const currentFingerprint =
                    DataManager.makeIndependentEquipTemplateFingerprint(
                        baseItem
                    );
                if (item._templateFingerprint === currentFingerprint) {
                    result.unchanged++;
                    continue;
                }

                try {
                    if (kind === 'item') {
                        migrateFingerprintedRegularItem(
                            item,
                            baseItem,
                            currentFingerprint
                        );
                    } else {
                        migrateFingerprintedItem(
                            item,
                            baseItem,
                            kind,
                            currentFingerprint
                        );
                    }
                    result.migrated++;
                } catch (error) {
                    result.failed++;
                    result.errors.push({
                        phase: 'fingerprinted',
                        kind,
                        id: item.id,
                        baseItemId: item.baseItemId,
                        message: error && error.message
                            ? String(error.message)
                            : String(error)
                    });
                    console.error(
                        '[YEP_ItemCore] Independent equipment migration ' +
                        'failed:',
                        kind,
                        item.id,
                        error
                    );
                }
            }
        }

        DataManager._lastIndependentEquipTemplateMigrationResult = result;
        return result;
    };
})();
